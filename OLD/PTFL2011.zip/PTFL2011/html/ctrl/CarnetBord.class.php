<?php
include_once 'control.class.php';

class CarnetBord extends Control {

    public function __construct($util, $get=null) {
        parent::__construct($util);

        $this->model();
        $model = new Model();
        
        //$this->setViewMenu();
 		
 		//informations de l'étudiant pour affichage
 		if (isset($get["eleve"])) $idEleve=$this->ha($get["eleve"]); else $idEleve=$this->util->getId();
	    //force l'identifiant à celui de l'étudiant.e pour éviter l'usurpation par un étudiant
	    if ($this->util->estEtudiant()) $idEleve=$this->util->getId();
	    $data["eleve"]=$idEleve;
	    $lEtudiant=$model->getEtudiant($data["eleve"]);
		$data["nomEtud"]=$lEtudiant[0]["prenom"]." ".$lEtudiant[0]["nom"];
	    
	    
	    if (isset($get["jour"])) $data["leJour"]=$this->ha($get["jour"]); else $data["leJour"]="1lu";
		//définit la semaine à afficher (0 pour les informations du stage)

	    //évite la possibilité de saisir des valeurs erronnées : restriction à 1ère ou 2è année
        if ($get["annee"]<2) $data["annee"]=1; else $data["annee"]=2;
        //gestion des onglets et des changements
        if (isset($get["semaine"])) $semaine=$this->ha($get["semaine"]); else $semaine=0;
        if (isset($get["modif"])) $modif=$this->ha($get["modif"]); else $modif="n";

		 //identifiant du stage selon l'année si les infos existent déjà
        $leStage=$model->getStage($idEleve,$data["annee"]);
		$data["nouveauMsg"]=0;
        if ($leStage==NULL)  
           {$idStage=0; 
             $data["nbSemaines"]=0;}
           else  //il y a un stage créé
           {$idStage=$leStage[0]["id"];  
            //nb de messages de l'interlocuteur (stagiaire ou référent)
            if ($this->util->estEtudiant()) $auteur="Référent.e"; else $auteur="Stagiaire";
            $data["nouveauMsg"]=$model->getNbMsgNouveaux($idStage, $auteur); 
            $data["pointages"]=$model->getPointages($idStage);  
			$data["stage"]=$leStage[0];         
			$data["nbSemaines"]=$model->getNbSemaines($idStage);
			$leReferent=$model->getReferentStage($idEleve,$data["annee"]);
			if ($leReferent==NULL) $data["leReferent"]=""; else $data["leReferent"]=$leReferent[0]["referent"];
			}
        //gestion des enregistrements
        if (isset($get["enregistrer"]) || $modif=="o"){ //cliqu√© bouton enregistrer ou changement onglet
          switch ($semaine){
            case 0 : //√©cran description du stage
            	if ($this->util->estEtudiant()){
	              $lieu=$this->ha($get["lieu"]);
	              $stage=$this->ha($get["annee"]);
	              $tuteur=$this->ha($get["tuteur"]);
	              $tutmail=$this->ha($get["tuteurmail"]);
	              $tuttel=$this->ha($get["tuteurtel"]);
	              $tutmob=$this->ha($get["tuteurmob"]);
	              $entreprise=$this->ha($get["entreprise"]);
	              $adresse=$this->ha($get["adresse"]);
	              $CP=$this->ha($get["cp"]);
	              $ville=$this->ha($get["ville"]);
	              $service=$this->ha($get["service"]);
	              $directeur=$this->ha($get["directeur"]);
	              $naf=$this->ha($get["naf"]);
	              $siret=$this->ha($get["siret"]);
	              $telEntreprise=$this->ha($get["telentreprise"]);
	              $fax=$this->ha($get["fax"]);
	              $melentreprise=$this->ha($get["melentreprise"]);
	              $horLun=$this->ha($get["horLundi"]);
	              $horMar=$this->ha($get["horMardi"]);
	              $horMer=$this->ha($get["horMercredi"]);
	              $horJeu=$this->ha($get["horJeudi"]);
	              $horVen=$this->ha($get["horVendredi"]);
	              $horSam=$this->ha($get["horSamedi"]);
	              $sujet=$this->ha($get["sujetStage"]); 
	              //renseigne l'année du stage en fonction de la période de saisie
	              if (date("m")<6) $anneeStage=date("Y"); else $anneeStage=date("Y")+1;
	          
				 if ($idStage==0){ //enregistrer donn√©es
	                  $numstage=$model->creeStage($lieu,$tuteur,$stage,$tutmail, $tuttel, $tutmob, $idEleve,$entreprise, $adresse, $CP, $ville, $service, $directeur, $naf, $siret, $telEntreprise, $fax, $melentreprise, $anneeStage);
	                   $leStage=$model->getStage($idEleve,$data["annee"]);
	           		   $numstage=$leStage[0]["id"]; 
	              	   $model->definirHoraire($numstage,$horLun,$horMar,$horMer,$horJeu,$horVen,$horSam);
	                   $model->definirSujet($numstage,$sujet);	                  
	             }
	              else { //modifier les donn√©es
	                  $model->majStage($idStage,$lieu,$tuteur,$stage, $tutmail, $tuttel, $tutmob,$entreprise, $adresse, $CP, $ville, $service, $directeur, $naf, $siret, $telEntreprise, $fax, $melentreprise);
	             	  $model->definirHoraire($idStage,$horLun,$horMar,$horMer,$horJeu,$horVen,$horSam);
	                  $model->definirSujet($idStage,$sujet);	
	              }
	             //actualisation suite aux MAJ
	              $leStage=$model->getStage($idEleve,$data["annee"]);
	              if (!($leStage==NULL)) {$data["carnet"]=$leStage[0]["id"];  $data["stage"]=$leStage[0];}
            	}
	             break;
	        case $data["nbSemaines"]+1 :
	        	{//gère le message du professeur référent ou du stagiaire
	        		$formulaire=$this->ha($get["form"]);
	        		if ($formulaire=="message") { //ajout d'un message
	        			$message=$this->ha($get["message"]);
	        			$auteur="";
	        			if ($this->util->estEtudiant()) $auteur="Stagiaire"; else $auteur="Référent.e";
	        			$model->setMessage($idStage,$message,$auteur);
	        		}
	        		elseif ($formulaire=="acquitter") {       			//acquittement des messages
	        			if ($this->util->estEtudiant()) $auteur="Référent.e"; else $auteur="Stagiaire";
	        			$model->acquitterMessages($idStage,$auteur);
	        			}	
	        			elseif ($formulaire=="pointer") {//pointage horaire
	        					$model->pointer($idStage,$semaine, date("Y-m-d"), date('H:i:s', time()), $_SERVER["REMOTE_ADDR"]);
	       			 	}       			
	        		//actualisation suite aux MAJ
	              $leStage=$model->getStage($idEleve,$data["annee"]);
	              $data["pointages"]=$model->getPointages($leStage[0]["id"]);
	              if (!($leStage==NULL)) {$data["carnet"]=$leStage[0]["id"];  $data["stage"]=$leStage[0];}
	        	break;}
			case $data["nbSemaines"]+2 :
	        	{//gère l'attestation de stage
	        		$debut=$this->ha($get["dateDebut"]);
	        		$fin=$this->ha($get["dateFin"]);
	        		$duree=$this->ha($get["dureeStage"]);
	        		$model->majDatesStages($idStage,$debut, $fin, $duree);
	        		//actualisation suite aux MAJ
	              $leStage=$model->getStage($idEleve,$data["annee"]);
	              if (!($leStage==NULL)) {$data["carnet"]=$leStage[0]["id"];  $data["stage"]=$leStage[0];}
	        	break;}
	        default : //activités d'une semaine donnée ou bilan de la semaine
	            $formulaire=$this->ha($get["form"]);
            	if ($this->util->estEtudiant()){
				 if ($formulaire=="taches") {   //ajout d'une nouvelle tâche
					 $jour=$this->ha($get["jour"]);
					 $domaine=$this->ha($get["domaine"]);
					 $desc=$this->ha($get["descr"]);
					 $duree=$this->ha($get["duree"]);
					 $model->ajoutetache($idStage,$semaine,$jour,$domaine,$duree,$desc);
					 }
				 elseif ($formulaire=="bilan") {   //informations du bilan
				 	$apprentissage=$this->ha($get["apprent"]);
				 	$bilan=$this->ha($get["bilan"]);
				 	$model->bilansemaine($idStage,$semaine,$apprentissage,$bilan);
				 	}				 	
            	 }
            	 //actualisation suite aux MAJ
	              $leStage=$model->getStage($idEleve,$data["annee"]);
	              if (!($leStage==NULL)) {$data["carnet"]=$leStage[0]["id"];  $data["stage"]=$leStage[0];}
	             break;
	             }
	             }
	    	if (isset($get["maj"])) {//mise à jour d'une tâche existante
	    		$laModif=$this->ha($get["tachemodif"]);
	    		$jour=$this->ha($get["jour".$laModif]);
				$domaine=$this->ha($get["domaine".$laModif]);
				$desc=$this->ha($get["descr".$laModif]);
				$duree=$this->ha($get["duree".$laModif]);
				$model->majtache($this->ha($get["latache"]),$jour,$domaine,$duree,$desc);
	    	}
	    	if (isset($get["suppr"]) && ($this->ha($get["modif"])=="true")) {//suppression d'une tâche existante
	    		$model->supprtache($this->ha($get["latache"]));
	    	} 
        $data["semaine"]=$semaine;
		$data["domaine"]=$model->getDomainesTaches();	
		$data["jours"]=$model->getJours();
        $data["carnet"]=$idStage;  
        //récupère les messages échangés
        if (!($leStage==NULL)) $data["messages"]=$model->getMessages($idStage,$auteur);
		$data["source"]=$model->getSource();
		//définit les onglets les semaines écoulées ou remplies
		for($numSem=1;$numSem<=$data["nbSemaines"];$numSem++) {
			$data["taches"."$numSem"]=$model->getTachesSemaine($numSem,$idStage);
		}		
		if ($semaine>0 && $semaine<=$data["nbSemaines"]) $data["laSemaine"]=$model->getLasemaine($idStage,$semaine);
        $model->close();

        $data["auth"]=$this->util->estAuthent();
        
        $this->setViewMenu();
        if ($semaine==0)   //saisie de base
        	$this->view->init('carnetBord.php',$data);
        else //tâches de la semaine
        	$this->view->init('saisieSemaine.php',$data);
        $this->setViewBas();



    }
    
}


?>
