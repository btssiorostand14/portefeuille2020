<?php  include_once 'exit.php'; ?>
<script language="javascript">
function getreqHttp(){//objet pour interagir avec la base
                var reqHttp = null;
			if(window.XMLHttpRequest) 	{
					// Firefox (Mozilla) et autres
				   	reqHttp = new XMLHttpRequest(); 				
				}
			else { if(window.ActiveXObject) 	{
					// Internet Explorer
				   	try { reqHttp = new ActiveXObject("Msxml2.XMLHTTP"); }
					catch (e) { reqHttp = new ActiveXObject("Microsoft.XMLHTTP");	}
					}
					else 	{
						// XMLHttpRequest non supportÈ par le navigateur
						 alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
						 reqHttp = false; 
					} 
			}
            return reqHttp;
}
		
function ajouter(pSemaine) {//envoi des données vers la base et ajout dans l'interface
	var cellule, ligne;
	//données pour insertion dans la base
	jour=document.getElementById('jour').value;
	duree=document.getElementById('duree').value;
	descr=document.getElementById('descr').value;
	domaine=document.getElementById('domaine').options[document.getElementById("domaine").selectedIndex].value;
	domaineText=document.getElementById('domaine').options[document.getElementById("domaine").selectedIndex].text;
	datas="sem="+pSemaine+",jour="+jour+",duree="+duree+",desc="+descr+",domaine="+domaine;   
	 var reqHttp=getreqHttp();
	                   //après le retour d'insertion, ajoute dans le tableau
                        	//ligne pour ajout dans le tableau HTML
					tableau = document.getElementById('tachesPassees');
					var nbLignes = tableau.rows.length; 
    				ligne = tableau.insertRow(-1);
    				cellule=ligne.insertCell(0);
    				cellule.innerHTML=jour;
    				cellule=ligne.insertCell(1);
    				cellule.innerHTML=domaineText;
    				cellule=ligne.insertCell(2);
    				cellule.innerHTML=duree;
    				cellule=ligne.insertCell(3);
    				cellule.innerHTML=descr;
                reqHttp.onreadystatechange = function() {
                if (reqHttp.readyState == 4 && reqHttp.status == 200)  {
      				jour = document.getElementById('jour');
      				jour.innerHTML="";
    				tableau.domaineText="";
    				tbleau.duree.innerHTML="";
    				tableau.descr.innerHTML="";
                }
                }
                 // ouvrir la connexion - mÈthode post
        reqHttp.open("POST","inserTache.php",true);			
        reqHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        // envoyer le code du contexte
        reqHttp.send(datas) ;
    
    Selection.innerHTML=Selection.innerHTML+ligneTableau;
}
</script>
<script type="text/javascript">
 <?php
   include "./vue/js/reste.js";
   include "./vue/js/verif.js";
 ?>
</script>

<?php


?>

<div id="corps">
<div id="navcontainer">
	<ul id="navlist">
	<?php 	
	   $semaine=$data["semaine"];	
      // include_once './vue/menus/menusemaine.php';//gere vers et depuis

?>
			</ul>
			</div>
<h1> Carnet de bord de stage <?php echo($data["annee"]); ?></h1>
<form name="infoStage" action="index.php" method="POST" onsubmit="return verif();">
<?php 	$lgc=60;
      //données d'interaction pour le traitement du formulaire
      echo '<input type="hidden" name="action" value="carnetBord2" />';
      echo '<input type="hidden" name="modif" value="n" />';
      echo '<input type="hidden" name="depuis" value="'.$semaine.'" />';

      echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
      echo '<input type="hidden" name="sem" value="'.$semaine.'" />';
      
      //données du formulaire
		echo  '<div class="libellebas">Lieu stage (nom et adresse <br/> de l\'entreprise) <span class="oblig">*</span> : </div>';

    	echo '<div class="champtexte"><textarea rows="4" cols="'.$lgc.'"  class="champOblig" name="lieu" ';
        echo ' size="64" maxlength="64"  onchange="change=true;">'; 
        	if (isset($data["stage"])) echo($data["stage"]["lieu"]);
        	echo '</textarea></div>';
        
        echo  '<div class="libelle">Coordonnées (nom, mail, téléphone) <br/>du tuteur/de la tutrice <span class="oblig">*</span> : </div>';
        
        echo '<div class="listeder"><textarea rows="4"  cols="'.$lgc.'" class="champOblig" name="tuteur" ';
        echo ' onchange="change=true;" >';        
        	if (isset($data["stage"])) echo($data["stage"]["coordonneesTut"]);
        	echo '</textarea></div>';
        
        echo '<div class="libellebas">Cadre : </div><div class="champtexte"><select  name="stage" onchange="change=true;">';
            $source=$data["source"];
            foreach ($source as $item) {
                  echo '<option value="'.$item["code"].'"';                  
        	if ($data["annee"]==$item["code"]) echo 'selected';
                  echo '>'.$item["libelle"].'</option>';
            }
            echo '</select>';
            echo '</div>';
            
?>
<div class="centrer"><span class="oblig">*</span> champ obligatoire<input type="submit" name="enregistrer" value="<?php if (isset($data["stage"])) echo("Mettre à jour"); else echo("Créer le carnet"); ?>"></div></form>

</div>
  