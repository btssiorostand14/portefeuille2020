<?php
include_once 'control.class.php';


class SuiviStage extends Control {

    public function __construct($util, $get=null) {
        parent::__construct($util);

        $this->model();
        $model = new Model();
        $data["auth"]=$this->util->estAuthent();
        $data["annee"]=$get["annee"];
       // if (!isset($get["num"])) {
          $data["liste"]=$model->getElevesGroupe($util->getNumGroupe()); 
          $data["suivi"]=$model->getElevesSuivi($data["liste"],$data["annee"]) ;        
          $data["stages"]=$model->getStagesEleves($data["liste"],$data["annee"]);
          $data["profs"]=$model->getProfsSIO();
          $data["droit"]=$this->util->estProf();

       /* } else {
          $l=$get["l"];
          if ($get["l"]=="p"){
          	$data["tableau"]=$model->getTableauSyntheseNew($get["num"]);
          	$data["synth"]=$model->getSynth($get["num"]);
          	$model->close();
          	$this->view->init('syntheseStages.php',$data);
          } else {
          	$data["bilan"]=$model->getBilan($get["num"]);
          	$model->close();
          	$this->setViewMenu();
        	$this->view->init('bilan.php',$data);
        	$this->setViewBas();
          }
        }*/
          if (isset($get["enregistrer"])) {
          		//Procède à l'enregistrement des affectation de stage
     			$model->affecterStage($get["lprofs"],$get["etud"],$get["annee"]);
     			$data["suivi"]=$model->getElevesSuivi($data["liste"],$data["annee"]) ;        
          }
        
          $model->close();
          $this->setViewMenu();
          $this->view->init('suiviStages.php',$data);
          $this->setViewBas();
    }
}


?>
