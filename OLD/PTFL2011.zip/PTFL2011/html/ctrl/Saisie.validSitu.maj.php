case 5 : //commentaires prof(s)
                 if ($commenter =="P" && $this->util->estProf())
            		if ($numsitu>0){
            		    $formulaire=$this->ha($get["frm"]);            	
				 		if ($formulaire=="enreg") {  //enregistrement d'un commentaire
            				$txt=$this->ha($get["commnew"]);
            				if ($txt!='') $model->setCommentaire($numsitu,$txt, $this->util->getId());
              				if (isset($get["chksup"])) $model->supprCommentaire($get["chksup"]);
              				if (isset($get["comm"])) $model->majCommentaire($get["commref"],$get["comm"]);
              			}
              		   else { // validation de la situation
              		     $model->validerSitu($numsitu);
              		   }
            		}
              	 break;