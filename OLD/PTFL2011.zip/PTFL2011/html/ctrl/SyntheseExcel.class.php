<?php
include_once 'control.class.php';

class SyntheseExcel extends Control {

    public function __construct($util, $get=null) {
        parent::__construct($util);

        $this->model();
        $model = new Model();

        //tableau reglementaire en premiere page
        $data["id"]=$util->getId();
        $model->close();

        $data["auth"]=$this->util->estAuthent();
        
        $this->setViewMenu();
        $this->view->init('syntheseExcel.php',$data);
		$this->setViewBas();


    }
}


?>
