<?php
//******************* AJOUTS POUR LA GESTION DES CARNETS DE BORD ***********************

//nombre de semaines renseign�es pour un carnet de bord d�fini
	public function getNbSemaines($pCarnet) {
		$req="Select nbSem from ".$this->pref."carnetbord where id=".$pCarnet;		
		$tbc=$this->mysql->execSQLRes($req);
      	return $tbc[0]["nbSem"]; 
	}
	
	public function getTachesSemaine($pSemaine,$pCarnet) {
	   //t�ches d'un carnet pour une semaine donn�e
		$laSemaine=$this->getLasemaine($pCarnet,$pSemaine);
		$req="Select ts.*, dt.libelle, j.code as journee from ".$this->pref."tachesemaine as ts, ".$this->pref."domainetaches as dt, 
			 ".$this->pref."semainecarnet as sc , ".$this->pref."jour as j
			 where ts.idDomaine=dt.id and ts.idSemaine=sc.id and ts.jour=j.code 
			 and idSemaine=".$laSemaine["id"]. " and idCarnet=".$pCarnet." order by j.code, ts.id";  
		$tbc=$this->mysql->execSQLRes($req);
      	return $tbc; 
	}
	
	public function getDomainesTaches(){
		$req="Select * from ".$this->pref."domainetaches";
		$tbc=$this->mysql->execSQLRes($req); 
      	return $tbc; 
	}
	
	public function creeStage($pLieu, $pTuteur, $pStage, $pEtudiant) {	   
	   $nbSem=5;
	   if ($pStage==2) $nbSem+=2;
	   $req="insert into ".$this->pref."carnetbord values ('',".$pStage.",'".$pTuteur."','".$pLieu."',".$pEtudiant.",".$nbSem.")";
	   $this->mysql->execSQL($req);
	   //r�cup�re le num�ro du carnet ainsi cr��
	   $req ="select max(id) as idmax from ".$this->pref."carnetbord";
	   $res=$this->mysql->execSQLres($req);
	   $numCarnet=$res[0]["idmax"];
	   //cr�e les entr�es pour les bilans hebdomadaires
	   for ($i=1;$i<=$nbSem;$i++) {
	   		$req="insert into ".$this->pref."semainecarnet value('',$numCarnet,$i,'','')";
	   		$this->mysql->execSQL($req);
	   }
	}
	
	public function majStage($pIdStage, $pLieu, $pTuteur, $pStage) {
	   $req="update ".$this->pref."carnetbord set  codeSource=".$pStage.", coordonneesTut='".$pTuteur."', lieu='".$pLieu."' where id=".$pIdStage;
	   $tbc=$this->mysql->execSQL($req);
	}
	
	public function getStage($pEtudiant,$pAnnee) {
		$req="Select * from ".$this->pref."carnetbord where idEtud=".$pEtudiant." and codeSource=".$pAnnee;
		$result=$this->mysql->execSQLres($req);		
		return $result;
	}
	
		public function majtache($pTache,$pJour,$pDomaine,$pDuree,$pDescr) {	
	//met � jour une  t�che de num�ro connu pTache
		$req="update ".$this->pref."tachesemaine set  jour='".$pJour."', idDomaine='".$pDomaine."', duree=".$pDuree.", description='".$pDescr."'";
		$req.=" where id=".$pTache;
		$this->mysql->execSQL($req);
	}

	public function supprtache($pTache) {	
	//supprime une tache dont le num�ro est fourni$
		$req="delete from ".$this->pref."tachesemaine where id=".$pTache;
		$this->mysql->execSQL($req);
	}
	
	public function bilansemaine($pCarnet,$pSemaine,$pApprent,$pBilan) {
		$idSemaine=$this->getLasemaine($pCarnet,$pSemaine);
		$req="update ".$this->pref."semainecarnet set apprentissage='".$pApprent."', bilan='".$pBilan."' where id=".$idSemaine["id"];
		$this->mysql->execSQL($req);
	}
	
	
	public function getJours(){
	   //jours de la semaine pour les activit�s quotidiennes
	   $req="select * from ".$this->pref."jour";
	   $res=$this->mysql->execSQLres($req);
	   return $res;	
	}
	
	
	public function getLasemaine($pCarnet,$pSemaine) { 
	 //identifiant de la semaine pour ce stage et ce num�ro de semaine
		$req="select * from ".$this->pref."semainecarnet where idCarnet=".$pCarnet." and numSemaine=".$pSemaine;
	    $res=$this->mysql->execSQLres($req);
	    return $res[0];	
	}
	
	public function ajoutetache($pStage,$pSemaine,$pJour,$pDomaine,$pDuree,$pDescr) {	
	//ajoute une nouvelle t�che pour un carnet et un num�ro de semaine (de 1 � 7)
		$idSemaine=$this->getLasemaine($pStage,$pSemaine);
		$req="insert into ".$this->pref."tachesemaine values('',".$idSemaine["id"].",'".$pJour."','".$pDomaine."',".$pDuree.",'".$pDescr."')";
		$this->mysql->execSQL($req);
	}
	

	public function getStagesEleves($pEleves,$pAnnee) {
		//retourne les informations concernant les stages des �tudiants
		$result=array();
		$i=1;
		foreach ($pEleves as $eleve) {
		   $req="Select id, cb.idEtud, lieu as Entreprise, coordonneesTut as Tuteur from ".$this->pref."carnetbord cb ";
		   $req.= " where cb.idEtud=".$eleve["num"]." and codeSource=".$pAnnee;
		   $result[$i++]=$this->mysql->execSQLres($req);
		}
		return $result;
	}
	
		public function getElevesSuivi($pEleves,$pAnnee) {
		//permet de r�cup�rer le professeur r�f�rent de chaque stage
		$result=array();
		$i=1;
		foreach ($pEleves as $eleve) {
		   $req="Select idEtud, prof.prenom as referent from ". $this->pref."suivistage st,".$this->pref."professeur prof ";
		   $req.=" where idEtud=".$eleve["num"]." and annee=".$pAnnee." and  st.idProf=prof.num";
		   $result[$i++]=$this->mysql->execSQLres($req);
		}
		return $result;
	}



?>
