<?php
include_once 'control.class.php';

class Notification extends Control {

    public function __construct($util, $get=null) {
        parent::__construct($util);

        $this->model();
        $model = new Model();        
        //$this->setViewMenu();
 		//nécessite l'authentification pour accéder au contenu
 		if ($this->util->estAuthent()) {
 		 if (isset($get["modif"])) $modif=$get["modif"]; else $modif="n";
 		 	$idUtil=$this->util->getId();
 		 	
 			if ($this->util->estEtudiant()) { //l'intervenant est un étudiant
 		  		$data["typeUtil"]="E"; 		  		
 		  		$data["lesNotifications"]=$model->getLesNotifsEtud($idUtil);
 		  		$data["commentaires"]=$model->getLesNotifsSitusEtud($idUtil);

  		    }
  		    else { //l'intervenant est un professeur
  		    	$data["typeUtil"]="P";
  		    	$data["lesNotifications"]=$model->getLesNotifsProf($idUtil);
  		    	$data["lesGroupes"]=$model->getGroupesProf($idUtil);
  		    	$data["lesAcquittements"]=$model->getAcquittements();  	
  		    	$data["commentaires"]=$model->getLesNotifsSitusProf($idUtil);	    	
  		    }
       	
 		if (isset($get["enregistrer"]) || $modif=="o"){ //cliqu√© bouton enregistrer ou changement onglet
       			if ($get["form"]=="Enreg") {
       			//enregistre les informations pour une nouvelle notif
       			$notSujet=$this->ha($get["sujet"]);
       			$notLibel=$this->ha($get["libelle"]);
       			$notGroupe=$this->ha($get["groupe"]);
       			$notEcheance=$this->ha($get["echeance"]);
       			$notAuteur=$idUtil;
       			if ($get["mode"]="enreg") { //création d'une nouvelle notification et récupération du numéro
       				$laNotif=$model->creeNotification($notSujet, $notLibel,$notGroupe,$notEcheance, $notAuteur);
       				//association pour chaque étudiant du groupe donné pour la dernière notitifcation créée
       				$model->associerNotif($notGroupe);
       				//actualise les inofs des notifications
       				$data["lesNotifications"]=$model->getLesNotifsProf($idUtil);
       			}
       			}
       			elseif ($get["form"]=="Acquit") { //acquittement d'une notification par un étudiant
       				$model->acquitterNotif($get["notif"],$idUtil);
       				//recharge les données des notifications
       				$data["lesNotifications"]=$model->getLesNotifsEtud($idUtil);
       			}
       			elseif ($get["form"]=="Suppr") {//suppression d'une notification par un prof
       				$model->supprimerNotif($get["notif"]);
       				//recharge les données des notifications
       				$data["lesNotifications"]=$model->getLesNotifsProf($idUtil);
       			}
       		}			
    }
        
        $model->close();

		$data["auth"]=$this->util->estAuthent();
		
        $this->setViewMenu();
       	$this->view->init('notification.php',$data);  
        $this->setViewBas();



    
}
}

?>
