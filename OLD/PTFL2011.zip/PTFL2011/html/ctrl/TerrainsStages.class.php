<?php
include_once 'control.class.php';

class TerrainsStages extends Control {

    public function __construct($util, $get=null) {
        parent::__construct($util);

        $this->model();
        $model = new Model();
        
        //$this->setViewMenu();
 		//informations des anciens stages avec critères éventuels de sélection
 		if (isset($get["ville"])) $ville=$get["ville"]; else $ville="";
 		if (isset($get["annee"])) $annee=$get["annee"]; else $annee="";
 		if (isset($get["dept"])) $dept=$get["dept"]; else $dept="";
 		$data["terrains"]=$model->getTerrains($ville, $annee, $dept);
 		$data["departements"]=$model->getDept();
 		$data["annees"]=$model->getAnnees();
 		$data["villes"]=$model->getVilles();
		
		$model->close();

        $data["auth"]=$this->util->estAuthent();
        
        $this->setViewMenu();
        $this->view->init('terrainsStages.php',$data);
        $this->setViewBas();



    }
    
}


?>
