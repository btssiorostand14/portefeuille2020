<?php
// 2016-09-04 Intégration correctif Alain Serres (usurpation situation) lignes [33..37]
include_once 'control.class.php';

class Saisie extends Control {

    private function dteusa($d){
      return substr($d,6,4)."-".substr($d,3,2)."-".substr($d,0,2);
    }

    private function nbJ($dd, $df) {
      $td = explode("-", $dd);
      $tf = explode("-", $df);
      $dif=mktime(0,0,0,$tf[1],$tf[2],$tf[0])-mktime(0,0,0,$td[1],$td[2],$td[0]);
      return $dif/86400;
    }


    public function __construct($util, $get=null) {
        parent::__construct($util);

        $this->model();
        $model = new Model();

        $this->setViewMenu();
        
		if (isset($get["vers"])) $vers=$this->ha($get["vers"]); else $vers=1;
        if (isset($get["depuis"])) $depuis=$this->ha($get["depuis"]); else $depuis=1;
        if (isset($get["numsitu"])) $numsitu=$this->ha($get["numsitu"]); else $numsitu=0;
         //contr�le la s�curit� pour les consultations par un �tudiant
         if ($this->util->estEtudiant()) if (!$model->appartientSitu($numsitu,$this->util->getId())) $numsitu=0;
        if (isset($get["commenter"])) $commenter=$this->ha($get["commenter"]); else $commenter="N";
        if (isset($get["modif"])) $modif=$this->ha($get["modif"]); else $modif="n";
		
		// 2016-09-04 Ce code est commenté dans la version de JPh Pujol : Commentaire /* */ supprimé.
        // pour avoir accès à une situation, il faut n'être pas étudiant (prof. , admin, etc.) ou être propriétaire de la situation
       // if ($this->util->estEtudiant()) $ok = $model->estProprietaire($this->util->getId(), $numsitu);
        //else 
        $ok = true;

        if (!$ok) $numsitu=0;  // dans l'existant une numsitu à zéro provoque l'accès à une nouvelle situation vierge
        

        //debut enregistrements
        if (isset($get["enregistrer"]) || $modif=="o"){ //cliqué bouton enregistrer ou changement onglet
          switch ($depuis){
            case 1 : //écran description
            	if ($this->util->estEtudiant()){
	              $lc=$this->ha($get["libcourt"]);
	              $de=$this->ha($get["description"]);
	              $pa=$this->ha($get["lieu"]);
	              $lo=$this->ha($get["localisation"]);
	              $so=$this->ha($get["source"]);
	              $ca=$this->ha($get["cadre"]);

	              $dd=$this->dteusa($this->ha($get["datedebut"]));
	              $df=$this->dteusa($this->ha($get["datefin"]));
	              if ($this->nbJ($dd,$df)<0) $df=$dd;
	              $ty=$this->ha($get["typedecrit"]);
	              $te=$this->ha($get["techno"]);
	              $ac=$this->ha($get["acteur"]);
	              $sg=$this->ha($get["situoblig"]);
	              $to=array();
	              if ($sg=="O" && isset($get["typologie"])) $to=$get["typologie"];
	              $av=$this->ha($get["avisperso"]);

	              $ideleve=$this->util->getId();

	              if ($numsitu==0){ //enregistrer données (voir model.class.php pour fonctions)
	                  $numsitu=$model->setDescription($lc,$de,$pa,$lo,$so,$ca,$to,$dd,$df,$ty,$te,$ac,$av,$ideleve);
	              } else { //modifier les données
	                  $model->updateDescription($numsitu,$lc,$de,$pa,$lo,$so,$ca,$to,$dd,$df,$ty,$te,$ac,$av);
	              }
            	}
	             break;

            case 2 : //écran caractérisation
            	if ($this->util->estEtudiant()){
            		$activchoisies=$this->ha($get["lesactivschoisies"]);
              		$model->gereActivChoisie($numsitu,$activchoisies);
            	}
              	break;
            case 3 : //saisie reformulation
            	if ($this->util->estEtudiant()){
            		$lescom=$get["comm"];
            		$idact=$get["idact"];
            		for ($i=0 ; $i<count($lescom) ;$i++)
            			$model->enregReformul($numsitu,$this->ha($lescom[$i]),$idact[$i]);
            	}
            	break;

			case 4 : // productions
				if ($this->util->estEtudiant()){
	              $de=$get["designation"]; // tableau de désignations
	              $ad=$get["adresse"]; // tableau des adresses
	              $codeP=$get["codeP"]; //tableau des codes productions
	              if (isset($get["chksup"])) $chksup=$get["chksup"]; else $chksup=null;
	              //les tableaux ont la même taille, sauf chksup
	              $nb=count($de);

	              for ($i=0;$i<$nb-1;$i++)
	                $model->updateProduction($numsitu,$codeP[$i],$this->ha($de[$i]),$this->ha($ad[$i]));
	              if ($de[$nb-1]!="")
	                $model->ajouteProduction($numsitu,$this->ha($de[$nb-1]),$this->ha($ad[$i]));
	              for ($i=0;$i<count($chksup);$i++)
	                $model->supprProduction($numsitu,$chksup[$i]);
				}
	            break;
			case 5 : //commentaires prof(s)
                 if ($commenter =="P" && $this->util->estProf())
            		{if ($numsitu>0){
            		    $formulaire=$this->ha($get["frm"]);            	
				 		if ($formulaire=="enreg") {  //enregistrement d'un commentaire
            				$txt=$this->ha($get["commnew"]);
            				if ($txt!='') $model->setCommentaire($numsitu,$txt, $this->util->getId());
              				if (isset($get["chksup"])) $model->supprCommentaire($get["chksup"]);
              				if (isset($get["comm"])) $model->majCommentaire($get["commref"],$get["comm"]);
              			}
              		   else { // validation ou signalement de la situation 
              		    if (isset($get["valider"])) 
              		    	{$model->validerSitu($numsitu);}
              		    else 
              		    	{$model->signalerSitu($numsitu);}
						//renvoi vers le tableau de bord
						header('Location: index.php?action=tableauBord');
              		   }
            		}
            		}
            	else { //information par un �tudiant d'une situation � �tudier           		
            		   $prof=$this->ha($get["prof"]);
            		   $model->informerSitu($numsitu,$prof);
            	}
              	 break;
          }
        } //fin gestion du bouton enregistrer

		//pr�paration donn�es ihm � afficher
        switch ($vers){
          case 1://donn�es situation
            $data=array("typesitu"=>$model->getTypeSitu(),
                        "localisation"=>$model->getLocalisation(),
                        "source"=>$model->getSource(),
                        "cadre"=>$model->getCadre(),
                        "type"=>$model->getType(),
            			"typologie"=>$model->getTypologie());
            if ($numsitu!=0)
              $data["lasitu"]=$model->getSitu1($numsitu);
            break;

          case 2://s�lection activit�s
          	$data=array("typeactiv"=>$model->getActivites(),
          				"lescomp"=>$model->getCompetences());
        	if ($numsitu!=0) {
              $data["lasitu"]=$model->getSitu3($numsitu);
              $data["lesactiv"]=$model->getSitu2($numsitu);
            }
            break;
          case 3 : //ecran reformulation activit�(s) par �l�ve
            if ($numsitu!=0)
              $data["lasitu"]=$model->getSitu3($numsitu);
              $data["lesactiv"]=$model->getSitu4($numsitu);
            break;

          case 4 ://saisie productions
            $data=array();
            if ($numsitu!=0) {
              $data["lasitu"]=$model->getSitu3($numsitu);
              $data["lesprod"]=$model->getProd($numsitu);
            }
            break;

		  case 5 ://saisie ou affichage commentaires profs
            $data=array();
            if ($numsitu!=0) {
              $data["lasitu"]=$model->getSitu3($numsitu);
              $data["lescomm"]=$model->getCommentaire($numsitu);
              $data["idprof"]=$this->util->getId();
            }
            break;
        }//fin pr�parations sp�cifiques

		//seules le sprofs MTI peuvent se voir signaler la situation
		$data["lesProfs"]=$model->getProfsMatiere("MTI");
        //pour toutes les ihm :
        $data["etudiant"]=$model->getAuteurSitu($numsitu);
        $model->close();

        $data["numsitu"]=$numsitu;
        $data["commenter"]=$commenter;
        $data["auth"]=$this->util->estAuthent();

        //appel page sp�cifique avec $data
        $this->view->init('saisie'.$vers.'.php',$data);
        $this->setViewBas();
    }
}

?>
