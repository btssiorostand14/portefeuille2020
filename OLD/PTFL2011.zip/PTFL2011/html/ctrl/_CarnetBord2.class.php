<?php
include_once 'control.class.php';

class CarnetBord2 extends Control {

    public function __construct($util, $get=null) {
        parent::__construct($util);

        $this->model();
        $model = new Model();
        
        //$this->setViewMenu();


	    $idEleve=$this->util->getId();
        $data["annee"]=$get["annee"];
        //identifiant du stage selon l'année si les infos existent déjà
        $leStage=$model->getStage($idEleve,$data["annee"]);
        if ($leStage==NULL) $idStage=0; else {$idStage=$leStage[0]["id"];$data["stage"]=$leStage[0]; }
        //gestion des onglets et des changements
        if (isset($get["semaine"])) $semaine=$get["semaine"]; else $semaine=0;
        if (isset($get["depuis"])) $depuis=$get["depuis"]; else $depuis=0;
        if (isset($get["modif"])) $modif=$get["modif"]; else $modif="n";

        //gestion des enregistrements
        if (isset($get["enregistrer"]) || $modif=="o"){ //cliqu√© bouton enregistrer ou changement onglet
          switch ($depuis){
            case 0 : //√©cran description du stage
            	if ($this->util->estEtudiant()){
	              $lieu=$this->ha($get["lieu"]);
	              $stage=$this->ha($get["stage"]);
	              $tuteur=$this->ha($get["tuteur"]);
	             if ($idStage==0){ //enregistrer donn√©es
	                  $numsitu=$model->creeStage($lieu,$tuteur,$stage,$idEleve);	                  
	             }
	              else { //modifier les donn√©es
	                  $model->majStage($idStage,$lieu,$tuteur,$stage);
	              }
	             //actualisation suite aux MAJ
	              $leStage=$model->getStage($idEleve,$data["annee"]);
	              if (!($leStage==NULL)) $data["stage"]=$leStage[0];
            	}
	             break;
	             }
	             }
        //informations de base du stage
		//$leStage=$model->getStage($idEleve,$data["annee"]);
		//if (!($leStage==NULL)) $data["stage"]=$leStage[0];
		$data["source"]=$model->getSource();
		$data["nbSemaines"]=$model->getNbSemaines($data["annee"]);
		//définit les onglets les semaines écoulées ou remplies
		for($nbSem=1;$nbSem<=$data["nbSemaines"];$nbSem++) {
			$data["taches"."$nbSem"]=$model->getTachesSemaine($nbSem);
		}		
		//définit la semaine à afficher (0 pour les informations du stage)
		$data["semaine"]=$semaine;
		$data["domaine"]=$model->getDomainesTaches();
        //puis une page par situation
        //pas vues dans cette version
        $data["synth"]=$model->getSynth($util->getId());
        $model->close();

        $data["auth"]=$this->util->estAuthent();
        
        $this->setViewMenu();
        if ($semaine==0)   //saisie de base
        	$this->view->init('carnetBord2.php',$data);
        else //tâches de la semaine
        	$this->view->init('saisieSemaine'.$semaine.'.php',$data);
        $this->setViewBas();



    }
    
}


?>
