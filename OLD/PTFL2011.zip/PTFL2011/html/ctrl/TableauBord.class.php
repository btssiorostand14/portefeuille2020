<?php
include_once 'control.class.php';

class TableauBord extends Control {

    public function __construct($util, $get=null) {
        parent::__construct($util);

        $this->model();
        $model = new Model();
        
        //$this->setViewMenu();
 		
 		//informations de l'utilisateur pour affichage
 		$util=$this->util->getId();
	    
		if ($this->util->estProf()) {
			$data["typeUtil"]="P";
			$data["notifs"]=$model->getLesNotifsProf($util);
			$data["acquittements"]=$model->getAcquittements();
			$data["carnets"]=$model->getLesStatsCarnet($util);
			$data["portefeuilles"]=$model->getLesStatsportefeuille($util);
			$data["situations"]=$model->getLesSituACommenter($util);
		}	 
		else {
			//données pour le tableau de bord des étudiants
			$data["typeUtil"]="E"; 		  		
 		  	$data["lesNotifications"]=$model->getLesNotifsEtud($util);
 		  	$data["carnets"]=$model->getLesCarnetsEtud($util);
 		  	$data["situations"]=$model->getLesSitusSignaleesEtud($util);
		}
		
		
        $model->close();

		$data["auth"]=$this->util->estAuthent();
		
        $this->setViewMenu();
       	$this->view->init('tableaubord.php',$data);
        $this->setViewBas();



    }
    
}


?>
