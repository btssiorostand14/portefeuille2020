<?php  include_once 'exit.php'; ?>
<div id="corps">

<div id="messavert">
  <?php
    $mess=$data["messagetexte"];
    if (!is_null($mess)) echo '<p>'.$mess.'</p>';
  ?>
</div>

<script type="text/javascript" src="./vue/js/fctverif.js"></script>
  <p>Cet onglet permet de modifier les informations concernant le compte d'acc&egrave;s.</p>
  
  <h2>Param&egrave;tres personnels</h2>
<form name="frmmodif" method="post" action="index.php" onsubmit="return verif(this);">
    <?php
      echo '<input type="hidden" name="action" value="modif" />';
      $num=$data["num"];
      echo '<input type="hidden" name="num" value="'.$num.'" />';

      $pers=$data["data"];
      $lngmdp=$data["lngmdp"];

    ?>
    <table>
      <tr>
        <td colspan="2">
          <hr />
        </td>
      </tr>
      <tr>
        <!--Nom-->
        <td> Nom :
        <?php
          echo '<input type="text" name="nom" size="20" maxlength="32" value="'.$pers[0]["nom"].'" />';
          if (!is_null($pers))
            echo '<input type="hidden" name="numpers" value="'.$pers[0]["num"].'" />';
        ?>
        <!--Prénom-->
        </td>
        <td> Pr&eacute;nom :
        <?php
          echo '<input type="text" name="prenom" size="20" maxlength="32" value="'.$pers[0]["prenom"].'" />';
        ?>
        </td>
      </tr>
      <tr>
      <td >Date de naissance :
        <?php
           echo '<input type="date" name="datenaiss" value="'.$pers[0]["datenaiss"].'" />';
        ?>
      </td>
      	<td> Sexe : 
      	<?php
           echo 'H <input type="radio" name="sexe" value="H"'; 
           if ($pers[0]["sexe"]=="H") echo ' checked="CHECKED"';
           echo '" />&nbsp;';
           echo 'F <input type="radio" name="sexe" value="F"'; 
           if ($pers[0]["sexe"]=="F") echo ' checked="CHECKED"';
           echo '" /> ';
        ?>
      	</td>
      </tr>
      <tr>
      <!--mel  et num exam -->
        <?php
          echo '<td';
          if ($num!=3) echo 'colspan="2"';
          echo '>Adresse m&eacute;l : ';
          echo '<input type="text" name="mel" size="32" maxlength="64" value="'.$pers[0]["mel"].'" />';
          echo '</td>';
          if ($num==3){
          	echo '<td>Num&eacute;ro examen : ';
          	echo '<input type="text" name="numexam" size="20" maxlength="16" value="'.$pers[0]["numexam"].'" />';
          	echo '</td>';
          }
        ?>
      <!--MDP-->
      <tr>
      <td colspan="2">Mot de passe :
        <?php
          echo '<input type="text" name="mdp" size="10" maxlength="'.$lngmdp.'" value="xxxx" />';
          echo ' Changer le mot de passe : <input type="checkbox" name="chmdp">';
        ?>
      </td>
      </tr>
      </table>

	  <h2>Coordonnées</h2>
      <table><tr><td colspan="2"><hr/></td><tr>
      <td >Mobile :
        <?php
          echo '<input type="text" name="mobile" value="'.$pers[0]["mobile"].'" />';
        ?>
      </td>
      <td >Photo (laisser vide):
        <?php
          echo '<input type="text" name="photo" value="'.$pers[0]["photo"].'" />';
        ?>
      </td>
      </tr>

      <tr>
      <td >Adresse Personnelle :<br/>&nbsp;
        <?php
          echo '<textarea cols="40" rows="3" maxlength="255" name="adrperso" >'.$pers[0]["adrperso"].'</textarea>';
        ?>
      </td>
      <td >Adresse Famille : <br/> si différente de votre adresse personnelle
        <?php
          echo '<textarea cols="40" rows="3" maxlength="255" name="adrfamille" >'.$pers[0]["adrfamille"].'</textarea>';
        ?>
      </td>
      </tr>

      <tr>
      <td >Tel Personnel :
        <?php
          echo '<input type="text" name="telperso" value="'.$pers[0]["telperso"].'" />';
        ?>
      </td>
      <td >Tel Famille : 
        <?php
          echo '<input type="text" name="telfamille" value="'.$pers[0]["telfamille"].'" />';
        ?>
      <br/> si différent de votre numéro personnel</td>
      </tr>
      </table>

  	  <h2>Scolarité</h2>
  	  <table><tr><td colspan="2"><hr/></td></tr><tr>
      <td >Bac : 
        <?php 
          	echo '<select  name="bac">';
			foreach ($data["lesBacs"] as $leBac) {
				echo '<option value="'.$leBac["id"].'"';
				if ($pers[0]["bac"]==$leBac["id"]) echo ' selected="SELECTED" ';
				echo '>'.$leBac["libellebac"].'</option>';
				}
			echo '</select>';
        ?>
      </td>
      <td >Specialite Bac :
        <?php 
echo '<input type="text" name="spebac" value="'.$pers[0]["spebac"].'" />';
        ?>
      </td>
      </tr>
	<tr>
      <td > Etablissement bac :
        <?php
          echo '<input type="text" name="etabbac" value="'.$pers[0]["etabbac"].'" />';
        ?>
      </td>
      <td >Post-Bac (éventuel) :
        <?php
          echo '<input type="text" name="postbac" value="'.$pers[0]["postbac"].'" />';
        ?>
      </td>
      </tr>

      

      <tr>
        <td colspan="2">
          <br />
          <hr />
        </td>
      </tr>
      <tr>
        <td colspan="2">
          <div class="centrer">
            <input type="submit" name="envoi" value="Enregistrer" />

          </div>
        </td>
      </tr>
    </table>

  </form>
</div>
