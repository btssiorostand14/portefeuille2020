<?php
/*
* NB: Fichiers modifiés: 
*	- semaine.php
* 	- class/model.class.php (fin du fichier)
* 	- vue/carbordPdf.php (ajout)
*/


/*
* Liste des choses à faire:
* Récupérer l'ID de l'étudiant actuellement connecté, le numéro du stage/carnet et le numéro de la semaine en cours
* Sécuriser (on peut changer l'id et obtenir le pdf pour quelqu'un d'autre)
* Créer des vues si mauvais incorrect, pas autorisation, etc?
*/

session_start();

require_once("class/model.class.php");
require_once("lib/dompdf/autoload.inc.php");

use Dompdf\Dompdf; 

if(isset($_POST["id"])) {
	//infos du formulaire
	$id = $_POST["id"];//numéro de l'étudiant
	$annee = $_POST["annee"]; //année du stage, 1 ou 2
	$j=1;
	$numeroSemaine = $_POST["semaine"];//semaine du stage de 1 à 7
	//On récupère les données du modèle.
	$model = new Model();
	
	$etudiant = $model->getEleveAttest($id)[0];	
	$nomEleve = $etudiant["nom"];
	$prenomEleve = $etudiant["prenom"];
	$datenaiss=$etudiant["datenaiss"];
	

	//récupération  des infos de la du carnet de bord
	$stage=$model->getStage($id,$annee)[0];
	$lesJours=$model->getJours();
	$lesDomaines=$model->getDomainesTaches();
	$semaine=$model->getLasemaine($stage["id"],1);
	$lesTaches=$model->getTachesSemaine($numeroSemaine,$stage["id"]); 
	$nomOrganisme = $stage["nomentreprise"];
	$adresseOrganisme = $stage["adresseentreprise"]."<br/>".$stage["codepostal"]." ".$stage["ville"];
	$telOrganisme = $stage["telentreprise"];
	$dateDebut=$stage["dateDebut"];
	$dateFin=$stage["dateFin"];
	$dureeStage=$stage["dureeStage"]; 
	
	

	$model->close();
ob_start();
	require_once("vue/stageCDBPdf.php");
	$htmlPdf = ob_get_clean();

	//On genere le pdf.
	$dompdf = new Dompdf();
	$dompdf->loadHtml($htmlPdf);
	$dompdf->setPaper('A4', 'portrait');
	
	$dompdf->render();
	$dompdf->stream("Carnet_".$nomEleve."_".$prenomEleve."_".$annee."_Semaine_".$numeroSemaine);

	//On inclut le fichier en cache et on l'envoie dans une variable (htmlPdf) avec ob_get_clean.
	/*ob_start();
	require_once("vue/stagePdf.php");
	$htmlPdf = ob_get_clean();

	//On genere le pdf.
	$dompdf = new Dompdf();
	$dompdf->loadHtml($htmlPdf);
	$dompdf->setPaper('A4', 'portrait');
	
	$dompdf->render(); 
	 
	$dompdf->stream("Carnet_".$nomEleve."_".$prenomEleve."_".$annee."_Semaine".$numSemaine);*/
	//header("Location: index.php");
} else {
	echo "Aucun id n'a été sélectionné!";
}
?>
