<?php
/*
* NB: Fichiers modifiés: 
*	- semaine.php
* 	- class/model.class.php (fin du fichier)
* 	- vue/carbordPdf.php (ajout)
*/


/*
* Liste des choses à faire:
* Récupérer l'ID de l'étudiant actuellement connecté, le numéro du stage/carnet et le numéro de la semaine en cours
* Sécuriser (on peut changer l'id et obtenir le pdf pour quelqu'un d'autre)
* Créer des vues si mauvais incorrect, pas autorisation, etc?
*/

session_start();

require_once("class/model.class.php");
require_once("lib/dompdf/autoload.inc.php");

use Dompdf\Dompdf; 

if(isset($_POST["numsitu"])) {  
	//infos du formulaire
	$numsitu=$_POST["numsitu"];
	//On récupère les données du modèle.
	$model = new Model();
	//récupération  des infos de la situation
	$situation=$model->getSitu1($numsitu);
	$activites=$model->getSitu4($numsitu);
	$id = $situation[0]["numEtudiant"];//numéro de l'étudiant 
	
	$etudiant = $model->getEleveAttest($id)[0];	
	$nomEleve = $etudiant["nom"];
	$prenomEleve = $etudiant["prenom"];
	$datenaiss=$etudiant["datenaiss"];
	

	 
	

	 
	

	$model->close();
	//On inclut le fichier en cache et on l'envoie dans une variable (htmlPdf) avec ob_get_clean.
	ob_start();
	require_once("vue/situPdf.php");
	$htmlPdf = ob_get_clean();

	//On genere le pdf.
	$dompdf = new Dompdf();
	$dompdf->loadHtml($htmlPdf);
	$dompdf->setPaper('A4', 'portrait');
	
	$dompdf->render();
	$dompdf->stream("Situation".$numsitu."_".$nomEleve."_".$prenomEleve);

} else {
	echo "Aucun id n'a été sélectionné!";
}
?>
