<?php
//noms des classes autoris�es
$cl= array("eaccueil","saisie","gestion","suppr","bilan","groupe","authent",
  "valid","passe","synthese","passprof","modif","sauve","recup",
  "suivigr","sauvebase","finetude","mpasse","chpromo","syntheseExcel", 
  "terrainsStages", "carnetBord", "notification", "tableauBord", "suiviStage");
?>
