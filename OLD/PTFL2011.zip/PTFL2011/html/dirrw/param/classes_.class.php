<?php
//noms des classes autoris�es
$cl= array("eaccueil","saisie","gestion","suppr","bilan","groupe","authent",
  "valid","passe","synthese","syntheseExcel","passprof","modif","sauve","recup",
  "suivigr","sauvebase","finetude","mpasse","chpromo");
?>
