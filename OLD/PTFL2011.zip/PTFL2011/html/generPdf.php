<?php
/*
* NB: Fichiers modifiés: 
*	- vue/menus/menug.php
* 	- class/model.class.php (fin du fichier)
* 	- vue/stagePdf.php (ajout)
*/


/*
* Liste des choses à faire:
* Récupérer l'ID de l'étudiant actuellement connecté
* Trouver un moyen de récupérer l'année ($_GET?)
* Sécuriser (on peut changer l'id et obtenir le pdf pour quelqu'un d'autre)
* Créer des vues si mauvais incorrect, pas autorisation, etc?
*/

session_start();

require_once("class/model.class.php");
require_once("lib/dompdf/autoload.inc.php");

use Dompdf\Dompdf; 

if(isset($_POST["id"])) {
	$id = $_POST["id"];
	
	//On récupère les données du modèle.
	$model = new Model();
	
	$etudiant = $model->getEleveAttest($id)[0];	
	$annee = $_POST["annee"]; 
	$lesSitus = $model->getSitusAttest($id,$annee);
	$nomEleve = $etudiant["nom"];
	$prenomEleve = $etudiant["prenom"];
	$datenaiss=$etudiant["datenaiss"];
	$sexe=$etudiant["sexe"];

	
	
	
	$stage = $model->getStageEtud($id, $annee)[0];
	
	$nomOrganisme = $stage["nomentreprise"];
	$adresseOrganisme = $stage["adresseentreprise"]."<br/>".$stage["codepostal"]." ".$stage["ville"];
	$telOrganisme = $stage["telentreprise"];
	$dateDebut=$stage["dateDebut"];
	$dateFin=$stage["dateFin"];
	$dureeStage=$stage["dureeStage"];
	
	

	$model->close();

	//On inclut le fichier en cache et on l'envoie dans une variable (htmlPdf) avec ob_get_clean.
	ob_start();
	require_once("vue/stagePdf.php");
	$htmlPdf = ob_get_clean();

	//On genere le pdf.
	$dompdf = new Dompdf();
	$dompdf->loadHtml($htmlPdf);
	$dompdf->setPaper('A4', 'portrait');
	
	$dompdf->render();
	$dompdf->stream("Attestation_stage_".$nomEleve."_".$prenomEleve."_".$annee);
	header("Location: index.php");
} else {
	echo "Aucun id n'a été sélectionné!";
}
?>
