<?php  include_once 'exit.php'; ?>
<div id="corps">

 <h2>Tableaux</h2>
  <p>Cette page permet de consulter les bilans ou les tableaux de synth&egrave;se (PDF) des
    &eacute;tudiants de votre promotion. Selon l'&eacute;tat d'avancement de leurs
    saisies, certains tableaux peuvent &ecirc;tre vides.</p>

<?php

  $eleves=$data["liste"];
  $stages=$data["stages"];
    echo '<table cellspacing="0">';

    echo '<tr><th>Nom</th><th>Pr&eacute;nom</th><th>Entreprise</th><th>Tuteur</th><th>Carnet de bord</th></tr>';
    $li=1;$i=1;
    foreach($eleves as $eleve){  
      echo '<tr><td class="td'.$li.'">'.$eleve["nom"].'</td>';
      echo '<td class="td'.$li.'">'.$eleve["prenom"].'</td>';
      if (isset($stages[$i][0])) {
         $entreprise=$stages[$i][0]["Entreprise"];
         $tuteur=$stages[$i][0]["Tuteur"];         
         $liensuivi='index.php?action=carnetBord&l=p&num='.$stages[$i][0]["id"]; } 
      else {$liensuivi="";$entreprise="";$tuteur="";}
      echo '<td class="td'.$li.'">'.$entreprise.'</td>';
      echo '<td class="td'.$li.'">'.$tuteur.'</td>';
	  echo '<td class="td'.$li.'"><a href="'.$liensuivi.'" target="_blank">carnet de bord</a></td>';
      echo '</tr>';
      if ($li==1) $li=2; else $li=1; //couleur des lignes
      $i++;
    }


?>
<!--
<form method="post" action="index.php">
    <?php
      echo '<input type="hidden" name="action" value="suiviStage" />';
    ?>
    <h3>SUIVI DES STAGES DE LA SECTION</h3>
	

</form>
-->
</div>
