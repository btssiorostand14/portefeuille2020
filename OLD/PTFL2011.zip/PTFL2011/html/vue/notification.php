<?php  include_once 'exit.php'; ?>

<script type="text/javascript">
 <?php
   include "./vue/js/reste.js";
   include "./vue/js/verif.js";
 ?>
</script>

<div id="corps">


<h1> Notifications </h1>
<form name="SaisieNotif" action="index.php" method="POST" onsubmit="return verif();">
<?php 
      //données d'interaction pour le traitement du formulaire
      echo '<input type="hidden" name="action" value="notification" />';
      echo '<input type="hidden" name="modif" value="n" />';
      echo '<input type="hidden" name="form" value="Enreg" />';
     
     
  if ($data["typeUtil"]=="P") {
  	//traitement du formulaire prof
  	echo  '<div class="libelle">Sujet <span class="oblig">*</span> : </div>';
  	echo '<div class="champtexte"><input type="text" size="70" maxlength="100"  class="champOblig" name="sujet" onchange="change=true;" ></input></div>';
    echo  '<div class="libelle">Texte de la notification <span class="oblig">*</span> : </div>';
    echo '<div class="champtexteb"><textarea rows="4" cols="70"  class="champOblig" maxlength="255" name="libelle" onchange="change=true;">';
 	echo '</textarea></div>';
 	echo  '<div class="libelle">Date fin de message<span class="oblig">*</span> : </div>';
 	echo '<div class="champtexte"><input type="text" size="10" maxlength="10"  class="champOblig" name="echeance" onchange="change=true;" ></input></div>';
    echo  '<div class="libelle">Groupe <span class="oblig">*</span> : </div>';
    echo '<div class="champtexte"><select name="groupe">';
    foreach ($data["lesGroupes"] as $groupe) {
    	echo '<option value="'.$groupe["num"].'">'.$groupe["libelle"].'</option>';
    }
    echo '</select></div>';
    echo '<div class="centrer"><span class="oblig">*</span> <input type="submit" name="enregistrer" value="Enregistrer"/></div>';
    echo '</form>';
    
  	//affiche les anciennes notifications
  	echo '<table border="1"><tr><th>Auteur</th><th>Sujet</th><th>Echéance</th><th>Promotion</th><th>Acquittements</th><th>Action</th></tr>';
  	foreach ($data["lesNotifications"] as $notif) {
  		echo '<tr><td>'.$notif["nomProf"].' '.$notif["prenom"].'</td><td>'.$notif["sujet"].'</td><td>'.$notif["echeance"].'</td><td>'.$notif["nomGroupe"].'</td>';
  		echo '<td>';
  			if (isset($data["lesAcquittements"][$notif["id"]])) echo $data["lesAcquittements"][$notif["id"]]; else echo "0";
  		echo '</td>';
  		echo '<td rowspan="2"><form name="suppr" action="index.php" method="POST">';
  		  	echo '<input type="hidden" name="action" value="notification" />';
     		 echo '<input type="hidden" name="form" value="Suppr" />';
     		 echo '<input type="hidden" name="notif" value="'.$notif["id"].'" />';
     		 echo '<input type="submit" name="enregistrer" value="Effacer" />';
		echo '</td></form>';     		 
     	echo '</tr>';
  		echo '<tr><td colspan="5">'.$notif["libelle"].'</td></tr>';  		
  	}
  	echo '</table>';
  }  
  else { //traitement de l'affichage étudiant
 //affiche les  notifications et permet leur acquittement
  	echo '<table border="1"><tr><th>Auteur</th><th>Sujet</th><th>Echéance</th><th>Statut</th></tr>';
  	foreach ($data["lesNotifications"] as $notif) {
  		echo '<tr';
  		if (!$notif["etat"]) echo ' bgcolor="FF6600"';
  		echo '><td>'.$notif["nom"].' '.$notif["prenom"].'</td><td>'.$notif["sujet"].'</td><td>'.$notif["echeance"].'</td>';
  		echo '<td rowspan="2">';
  		if ($notif["etat"]) { echo 'Acquitté';} 
  		else {echo '<form name="acquitter" action="index.php" method="POST">';
  			  echo '<input type="hidden" name="form" value="Acquit" />';
  			  echo '<input type="hidden" name="action" value="notification" />';
  			  echo '<input type="hidden" name="notif" value="'.$notif["id"].'" />';
  			  echo '<input type="submit" name="enregistrer" value="J\'ai lu" />';
  			  echo '</form>';}
  		echo '</td></tr>';
  		echo '<tr'; if (!$notif["etat"]) echo ' bgcolor="FF6600"'; echo '><td colspan="3">'.$notif["libelle"].'</td></tr>';
  		}
  	echo '</table>'; 
  	}
?>
     
  