<div id="corps">

<?php echo '<span id="situtete"><br/>'.$data["nomEtud"].'</span>'; ?>
<div id="navcontainer">
<ul id="navlist">
<?php
$semaine=$data["semaine"];
$nouveau=$data["nouveauMsg"]["nb"]>0;
include_once './vue/menus/menusemaine.php';//gere les onglets
?>

</ul>
</div>

<script type="text/javascript">
 <?php
   include "./vue/js/reste.js";
   include "./vue/js/verif.js";
 ?>
</script>
<?php	
function lesJours($lesJours,$pNomListe, $pSelection) {
	//affiche les jours de la semaine dans une liste
	$listeJours='<select name="'.$pNomListe.'">';
	foreach ($lesJours as $leJour) {
		$listeJours.='<option value="'.$leJour["code"].'"';
		if ($leJour["code"]==$pSelection) $listeJours.=' selected';
		$listeJours.='>'.$leJour["libelle"].'</option>';
	}
	$listeJours.='</select>';
	return $listeJours;
}
function lesDomaines($pLesDomaines, $pNomListe, $pSelection) {
	//affiche les domaines des tâches menées
 	$listeDomaines='<select name="'.$pNomListe.'"> ';
    	foreach ($pLesDomaines as $item) {
        	$listeDomaines.='<option value="'.$item["id"].'"';
        	if ($item["id"]==$pSelection) $listeDomaines.=' selected';
    		$listeDomaines.='>'.$item["libelle"].'</option>';
        }
	$listeDomaines.='</select>';
	return $listeDomaines;
}
function afficheTableauTaches($pLesTaches, $pLesDomaines, $lesJours, $pLeJour) {
	//affiche un tableau permettant la saisie d'une nouvelle tache et restituant les taches passées pour cette semaine
	echo '<table id="tachesPassees" border="1" cellspacing="0" name="ajoutTaches"><tr><th>Jour</th><th>Domaine</th><th><span class="oblig">*</span>Dur&eacute;e <br/>(en h)</th><th><span class="oblig">*</span>Description</th><th></th></tr>';
	//zone pour la saisie d'une nouvelle tâche  
	echo '<tr><td>'.lesJours($lesJours,"jour",$pLeJour).'</td><td>'.lesDomaines($pLesDomaines,"domaine","Adm").'
			</td><td><input type="text" name="duree" size="1" class="champOblig"/>h</td>
	   		<td><textarea cols="40" rows="3" maxlength="255" name="descr" class="champOblig"></textarea></td><td><input type="submit" name="enregistrer" value="Enregistrer la tâche" onclick="return verif();submit();"></td></tr>';
	$numTache=1;
	//tâches issues de la base
	foreach ($pLesTaches as $tache) {
		echo'<tr><td>'.lesJours($lesJours,"jour".$numTache,$tache["journee"]).'</td><td>'.lesDomaines($pLesDomaines,"domaine".$numTache,$tache["idDomaine"]).'</td>';
		echo '<td><input type="text" name="duree'.$numTache.'" size="2" value="'.$tache["duree"].'"/></td><td><textarea maxlength="255" cols="40" rows="3" name="descr'.$numTache.'">'.$tache["description"].'</textarea></td>';
		echo '<td><div class="centrer"><input type="submit" name="maj" onClick="setTache('.$tache["id"].','.$numTache.')" value="MàJ"';
		echo '><input type="submit" name="suppr" onClick="setTacheSuppr('.$tache["id"].','.$numTache.')" value="DEL"></div></td></tr>';
		$numTache++;
	}
	echo '</table>';
}

function afficheTableauMessages($pLesMessages) {	
     //affiche un tableau reprenant les messages passés pour ce stage
	$nummsg=1;
	echo '<div class="centrer"><table border="1"><tr><th>Date</th><th>Messages</th><th>Auteur</th></tr>'; 
	foreach ($pLesMessages as $message) {
		echo'<tr><td>'.$message['datemsg'].'</td><td>'.$message["commentaire"].'</td><td>'.$message["auteur"].'</td></tr>';
		//echo '<td><div class="centrer"><input type="submit" name="maj" onClick="setTache('.$tache["id"].','.$numTache.')" value="MàJ"';
		//echo '><input type="submit" name="suppr" onClick="setTacheSuppr('.$tache["id"].','.$numTache.')" value="DEL"></div></td></tr>';
		$nummsg++;
	}
	echo '</table></div>';
}

function afficheTableauPointage($pLesPointages) {	
     //affiche un tableau reprenant les messages passés pour ce stage
	$nummsg=1;
	echo '<div class="centrer"><table border="1"><tr><th>Date</th><th>Heure (GMT)</th><th>IP</th></tr>'; 
	foreach ($pLesPointages as $pointage) {
		echo'<tr><td>'.$pointage['datepoint'].'</td><td>'.$pointage["heurepoint"].'</td><td>'.$pointage["ip"].'</td></tr>';
		$nummsg++;
	}
	echo '</table></div>';
}

if ($semaine<=$data["nbSemaines"]) { ?>
<h2>Activité Quotidienne
	<form action="generCDBPdf.php" method="post">
		<input type="hidden" name="id" value="<?php echo $data["eleve"] ?>"/>
		<input type="hidden" name="annee" value="<?php echo $data["annee"]; ?>"/>
		<input type="hidden" name="semaine" value="<?php echo $semaine; ?>"/>
		<input type="submit" value="Générer PDF"/>
	</form>
</h2>
<form name="infoStage" id="infoStage" method="post" action="index.php" >
<?php  //formulaire des tâches
      echo '<input type="hidden" name="action" value="carnetBord" />';
      echo '<input type="hidden" name="modif" value="n" />';
     // echo '<input type="hidden" name="depuis" value="'.$semaine.'" />';      
      echo '<input type="hidden" name="semaine" value="'.$semaine.'" />';      
      echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
      echo '<input type="hidden" name="carnet" value="'.$data["carnet"].'" />';
      echo '<input type="hidden" name="form" value="taches"/>';
      echo '<input type="hidden" name="latache" value="0"/>';
      echo '<input type="hidden" name="tachemodif" value="0"/>';
      echo '<input type="hidden" name="eleve" value="'.$data["eleve"].'" />';

      if (isSet($data["taches".$semaine]))  afficheTableauTaches($data["taches".$semaine], $domaines=$data["domaine"], $data["jours"], $data["leJour"]);
if (!(isset($_GET["mode"]))) {?>
    <div class="centrer"><span class="oblig">*</span> champ obligatoire</div>
<?php } ?>
  </form>
  
<hr/><br/>
<h2>Bilan de la semaine</h2>
<form name="infoBilan" id="infoBilan" method="post" action="index.php"> 
<?php   //formulaire du bilan
      echo '<input type="hidden" name="action" value="carnetBord" />';
      echo '<input type="hidden" name="modif" value="n" />';      
      echo '<input type="hidden" name="semaine" value="'.$semaine.'" />';      
      echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
      echo '<input type="hidden" name="carnet" value="'.$data["carnet"].'" />';
      echo '<input type="hidden" name="form" value="bilan"/>';
       echo  '<div class="libellebas">Apprentissages : </div>';
       echo '<div class="champtexte"><textarea cols="70" rows="3" maxlength="255" name="apprent" >'.$data["laSemaine"]["apprentissage"].'</textarea></div>';
       echo '<div class="libellebas">Bilan et difficultés : </div>';
       echo '<div class="champtexte"><textarea cols="70" rows="3" maxlength="255" name="bilan" >'.$data["laSemaine"]["bilan"].'</textarea></div><br/>';
 		if (!(isset($_GET["mode"]))) {?>    
      		<div class="centrer"><input type="submit" name="enregistrer" value="Enregistrer le bilan"></div>
 <?php }; ?>   
 </form>
 <?php } 
 	else { //échanges ou attestation
		if ($semaine==$data["nbSemaines"]+1) { //échanges entre stagiaire et référent
 	  		echo '<h2>Communications entre stagiaire et référent.e </h2>';
 	  		echo '<form name="infoStage" id="infoStage" action="index.php" method="post">';
 	  		echo '<input type="hidden" name="action" value="carnetBord" />';
      		echo '<input type="hidden" name="modif" value="n" />';    
    	  	echo '<input type="hidden" name="semaine" value="'.$semaine.'" />';      
      		echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
     		echo '<input type="hidden" name="carnet" value="'.$data["carnet"].'" />';
     		echo '<input type="hidden" name="eleve" value="'.$data["eleve"].'" />';       
     		echo '<input type="hidden" name="form" value="pointer"/>';
     		echo '<div class="centrer"><input type="submit" name="enregistrer" value="Pointer"/></div>';
 	  		echo '</form><hr/>';
 	  		echo '<form name="infoStage" id="infoStage" method="post" action="index.php" >';
 	  		echo '<input type="hidden" name="action" value="carnetBord" />';
      		echo '<input type="hidden" name="modif" value="n" />';    
    	  	echo '<input type="hidden" name="semaine" value="'.$semaine.'" />';      
      		echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
     		echo '<input type="hidden" name="carnet" value="'.$data["carnet"].'" />';
     		echo '<input type="hidden" name="eleve" value="'.$data["eleve"].'" />';      
     		echo '<input type="hidden" name="form" value="message"/>';
      		echo '<div class="libellebas">Nouveau message : </div>';
      		echo '<div class="champtexte"><textarea cols="70" rows="3" maxlength="255" name="message" ></textarea></div><br/>';
			if (!(isset($_GET["mode"]))) {  
      			echo '<div class="centrer"><input type="submit" name="enregistrer" value="Ajouter"></div><br/>';}
 			echo '</form>';  			
    		if ($data["nouveauMsg"]["nb"]>0) {    			
    			//formulaire pour acquitter les messages
				echo '<form name="infoStage" id="infoStage" method="post" action="index.php" >';
 				echo '<input type="hidden" name="action" value="carnetBord" />';
    			echo '<input type="hidden" name="modif" value="n" />';    
    			echo '<input type="hidden" name="semaine" value="'.$semaine.'" />';      
    			echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
	    		echo '<input type="hidden" name="carnet" value="'.$data["carnet"].'" />';
    			echo '<input type="hidden" name="eleve" value="'.$data["eleve"].'" />';      
    			echo '<input type="hidden" name="form" value="acquitter"/>';
    			echo '<div class="centrer"><input type="submit" name="enregistrer" value="Acquitter les nouveaux messages"></div>';
    			echo '</form>';}    				
 			afficheTableauMessages($data["messages"]);
 			echo '<hr/><h3>Pointages</h3>';
 			afficheTableauPointage($data["pointages"]); 
 			}
 	  	else {  //attestation de stage
 	  		echo '<form name="infoStage" id="infoStage" method="post" action="index.php" >';
 	  		echo '<input type="hidden" name="action" value="carnetBord" />';
      		echo '<input type="hidden" name="modif" value="n" />';     
    	  	echo '<input type="hidden" name="semaine" value="'.$semaine.'" />';      
      		echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
     		echo '<input type="hidden" name="carnet" value="'.$data["carnet"].'" />';
     		echo '<input type="hidden" name="eleve" value="'.$data["eleve"].'" />';      
     		echo '<input type="hidden" name="form" value="attestation"/>';
     		echo '<b>Renseignez d\'abord l\'ensemble des informations de votre profil (menu <a href="index.php?action=modif">paramètres</a>).</b>';
     		echo '<br/>Complétez les dates effectives et la durée du stage ci-dessous';
      		echo '<div class="libelle">Date de début du stage : </div>';
      		echo '<div class="champtexte"><input type="date" name="dateDebut" size="2" class="champOblig" value="'.$data["stage"]["dateDebut"].'"/></div><br/>';
      		echo '<div class="libelle">Date de fin du stage : </div>';
      		echo '<div class="champtexte"><input type="date" name="dateFin" size="2" class="champOblig" value="'.$data["stage"]["dateFin"].'"/></div><br/>';
      		echo '<div class="libelle">Durée du stage : </div>';
      		echo '<div class="champtexte"><input type="text" name="dureeStage" size="1" class="champOblig" value="'.$data["stage"]["dureeStage"].'"/> semaines</div><br/>';
			if (!(isset($_GET["mode"]))) {?>    
      			<div class="centrer"><input type="submit" name="enregistrer" value="Enregistrer les informations"></div>
 	  	    <?php };  
  	  		echo '</form>';
  	  		echo '<hr/>';
  	  		echo '<form name="generer" method="post" action="generPdf.php" >';
  	  		echo '<input type="hidden" name="id" value="'.$data["eleve"].'" />'; 
      		echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />'; 
  	  		echo '<input type="submit" name="enregistrer" value="Générer l\'attestation">';
  	  		echo '</form>';
		}
	}
 	
  ?>
  </div>

