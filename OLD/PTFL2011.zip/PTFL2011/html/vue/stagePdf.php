<meta charset="utf-8"/>

<style>
div {
		font-size: 13px;
		margin-bottom: 5px;
		margin-top: 5px;
		border: 0px;
	}
	
.cadre {
		border: 1px solid black;
		margin-bottom: 5px;
		font-size: 13px;
	}
	
.petit {
		font-size: 8px;
	}
	
.right { 
		text-align: right;
	}
	
.centre {
		margin-left: 50px;
		margin-right: 50px;
		text-align: center;
	}
	
h1 {
		text-align: center;
		font-size: 16px;
	}
	
h2 {
		text-align: center;
		font-size: 14px;
	}

body {
		font-family: Arial;
	}


div.breakafter {
  page-break-after: always;
}
</style>

<div>

<div class="right"><h1>ATTESTATION DE STAGE</h1></div>
<div>logo ou tampon de l'entreprise </div>
<div class="right">Recto</div>
<div class="cadre">
	<h1>Organisme d'acccueil</h1>
	<p><b>Nom ou dénomination sociale :</b> <?=$nomOrganisme?></p>
	<p><b>Adresse :</b> <?=$adresseOrganisme?> </p>
	<p><b>Téléphone :</b> <?=$telOrganisme ?> </p>
</div>

<div>
	<h2>Certifie que <?php if ($sexe=="H") echo "le"; else echo "la"?> stagiaire</h2>
</div>



<div class="cadre">
	<h1><?php if ($sexe=="H") echo "LE"; else echo "LA"?> STAGIAIRE</h1>
	<table><tr><td>Nom : &nbsp;&nbsp;&nbsp;&nbsp;<b><?=$nomEleve?></b>&nbsp;&nbsp;&nbsp;&nbsp; Prénom :&nbsp;&nbsp;&nbsp;&nbsp; <b><?=$prenomEleve?></b> &nbsp;&nbsp;&nbsp;&nbsp;
				<td class="right">Sexe : F [ <?php if ($sexe=="F") echo "X";?> ] &nbsp;&nbsp; H [ <?php if ($sexe=="H") echo "X";?> ] 
				<td class="right"> &nbsp;&nbsp; Né<?php if ($sexe=="F") echo "e";?>  le : <b><?php  $datenaissfr=substr($datenaiss,8,2)."/".substr($datenaiss,5,2)."/".substr($datenaiss, 0,4);echo($datenaissfr) ; ?></b></table>
	<p>Adresse : <?=$etudiant["adrperso"]?>  </p>                            
	<p>ÉTUDIANT<?php if ($sexe=="F") echo "E";?>  EN <b>…………BTS Services informatiques aux organisations………… option   [ <?php if ($etudiant["idParcours"]==1) echo "X";?> ] SISR   &nbsp;&nbsp;    [ <?php if ($etudiant["idParcours"]==2) echo "X";?>  ] SLAM </b></p>
	<p>AU SEIN DU …………………Lycée Jean Rostand à Caen…………………</p>
</div>
<div>
	<h2>a effectué un stage prévu dans le cadre de ses études</h2>
</div>
<div class="cadre">
	<h1>DURÉE DU STAGE </h1>
	<p>Dates de début et de fin du stage : Du  <b><?php echo substr($dateDebut,8,2)."/".substr($dateDebut,5,2)."/".substr($dateDebut,0,4); ?></b>
	  au <b><?php echo substr($dateFin,8,2)."/".substr($dateFin,5,2)."/".substr($dateFin,0,4); ?>.</b></p>
	<p>Représentant une durée totale de <?=$dureeStage?> semaines.</p>
	<div class="petit">
		La durée totale du stage est appréciée en tenant compte de la présence effective de la ou 
		du stagiaire dans l’organisme, sous réserve des droits à congés et autorisations d’absence 
		prévus à l’article L.124-13 du code de l’éducation (art. L.124-18 du code de l’éducation). 
		Chaque période au moins égale à 7 heures de présence consécutives ou non est considérée 
		comme équivalente à un jour de stage et chaque période au moins égale à 22 jours de présence 
		consécutifs ou non est considérée comme équivalente à un mois.
	</div>
</div>
<div class="cadre">
	<h1>MONTANT DE LA GRATIFICATION VERSÉE <?php if ($sexe=="H") echo "AU"; else echo "A LA"?> STAGIAIRE</h1>                                                                                                                          
	<p>La ou le stagiaire a perçu une gratification de stage pour un montant total de ……………………….. €</p>
</div>
<div class="breakafter"></div>
<div class="right">Verso</div>
<div class="centre"><h3>La tutrice ou le tuteur de l’organisation d’accueil certifie que les situations professionnelles, 
vécues ou observées, présentées par <?php if ($sexe=="H") echo "le"; else echo "la"?> stagiaire dans son portefeuille de compétences professionnelles 
listées ci-dessous ont bien été réalisées dans le cadre de son stage.</h3></div>
<div> <p class="centre"> OUI [&nbsp;&nbsp;  ]	&nbsp;&nbsp;&nbsp;&nbsp; NON  [&nbsp;&nbsp;] </p>  </div>

<div class="cadre">Intitulé de la situation professionnelle
<?php 
echo "<ul>";
foreach($lesSitus as $laSitu) {
	echo "<li>".$laSitu['libcourt'];
}
echo "</ul>";
?>
</div>	
	
	

<div><table><tr><td class="petit">L’attestation de stage est indispensable pour pouvoir, sous réserve du versement d’une cotisation, 
faire prendre en compte le stage dans les droits à retraite. La législation sur les retraites (loi n°2014-40 du 20 janvier 2014) 
ouvre aux étudiants dont le stage a été gratifié la possibilité de faire valider celui-ci dans la limite de deux trimestres, 
sous réserve du versement d’une cotisation. La demande est à faire par l’étudiant(e) dans les deux années suivant la fin du stage 
et sur présentation obligatoire de l’attestation de stage mentionnant la durée totale du stage et le montant total 
de la gratification perçue. Les informations précises sur la cotisation à verser et sur la procédure à suivre sont à demander 
auprès de la Sécurité sociale (code de la Sécurité sociale art. L.351-17 – code de l’éducation art..D.124-9).<td>
<p>FAIT À ………………………….. <br/><br/>LE ……………………</p>
<div><p> </p><p> </p><p> </p><p> </p></div>
<p>Nom, fonction et signature du représentant de l’organisme d’accueil</p></table></div>





