<?php  include_once 'exit.php'; ?>
<div id="corps">

<h1> G&eacute;n&eacute;ration du tableur Excel</h1>
<form action="generExcel.php?id=<?php echo $data['id'] ?>" method="POST" target="_blank">
<p>Vous pouvez g&eacute;n&eacute;rer le tableau des situations et activit&eacute; au format Excel
</p><p>Vous pourrez ensuite proc&eacute;der &agrave; une analyse de votre travail et ne retenir 
<br>que les &eacute;l&eacute;ments significatifs repr&eacute;sentant l'&eacute;volution de votre parcours professionnel</>
<p>Vous supprimerez les lignes blanches inutiles
</p>
<input type="submit" value="G&eacute;n&eacute;rer"></form>
</div>
  