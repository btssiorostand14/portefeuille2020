<?php header("Location:index.php?action=tableauBord"); ?>
<div id="corps">
<h3>Chaque titre d'un sous-menu h&eacute;berge un lien vers une rubrique d'aide contextuelle</h3>
  <h2>Situations</h2>
  <p>Vous saisissez de nouvelles situations ou g&eacute;rez celles d&eacute;j&agrave; 
    saisies. Le libell&eacute; court d'une situation sert d'identifiant dans les 
    interfaces o&ugrave; elle doit &ecirc;tre s&eacute;lectionn&eacute;e ainsi 
    que dans le tableau de synth&egrave;se (&agrave; choisir donc avec pertinence).</p>
  <h2>Synth&egrave;se</h2>
  <p>Le <i>bilan individuel</i> vous permet d'observer, parmi toutes les activit&eacute;s
    et comp&eacute;tences du r&eacute;f&eacute;rentiel, celles qui sont cit&eacute;es
    dans vos situations.</p>
  <p>Vous pouvez aussi construire, puis sauvegarder ou imprimer, le tableau de 
    synth&egrave;se au format PDF. Le num&eacute;ro d'examen figurant en en-t&ecirc;te 
    sera fourni par la convocation et devra &ecirc;tre initialis&eacute; dans 
    les donn&eacute;es personnelles (voir ci-dessous).</p>
  <h2>Divers</h2>
  <p>Vous devez sauvegarder r&eacute;guli&egrave;rement vos donn&eacute;es
    sur un support personnel (cl&eacute; USB par exemple) ; une &eacute;ventuelle
    restauration sera r&eacute;alis&eacute;e par un de vos professeurs.</p>
  <p>Vous pouvez aussi modifier vos informations personnelles, mot de passe par 
    exemple.</p>
  </div>
