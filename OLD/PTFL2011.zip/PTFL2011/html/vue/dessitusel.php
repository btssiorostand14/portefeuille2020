<?php  include_once 'exit.php'; ?>
<div id="corps">
    <?php
      $vers=1;
      $liste=$data["lessitusel"];
    ?>
<h2>Situations</h2>
<script type="text/javascript">
 <?php
   include "./vue/js/reste.js";
   include "./vue/js/verif.js";
 ?>

</script>

<div class="titre">Cette page permet d'&eacute;diter une situation en cliquant sur "Accéder", 
		  de la supprimer, de la r&eacute;cup&eacute;rer si la suppression
          n'est pas souhait&eacute;e ou de la d&eacute;truire d&eacute;finitivement.
          Entre parenth&egrave;ses vous sont indiqu&eacute;s les nombres de commentaires, d'activit&eacute;s
           cit&eacute;es et de productions pour chaque situation.<br/>
           <span id="situinform">Les situations en violet ont fait l'objet d'un commentaire par un(e) enseignant(e)</span><br/>
           <span id="situvisee">Les situations en bleu ont été visées par un(e) enseignant(e). Les modifications ultérieures ne seront pas étudiées</b></span>
           
           </div>
<form name="consultSitu" id="consultSitu" method="post" action="index.php" >
<?php //formulaire des tâches
      echo '<input type="hidden" name="action" value="saisie" />';   
      echo '<input type="hidden" name="vers" value="'.$vers.'" />';  
      echo '<input type="hidden" name="mode" value="1" />';
      echo '<input type="hidden" name="numsitu" value="0" />';      
      echo '<input type="hidden" name="t" value="s" />';
?>
  <table cellspacing="0" border="0">
  <?php
    $li=1;
    $ln=50;
    $ids=0;

    foreach ($liste as $ligne) {

      $valide=$ligne["valide"];
      //$commenter=$ligne["validation"];
      //$commenter=0;
      $commentaire=$ligne["commentaire"];
      $activ=$ligne["activ"];
	  $prod=$ligne["prod"];
      //pour la mise en évidence des situations validées
      if ($ligne["valideeProf"]!="1") 
      	if ( $ligne["signalEtud"]) $leStyle="situinform";
      		else $leStyle="";
      	 else $leStyle="situvisee";
      $ref=$ligne["ref"];
      echo '<tr>';

      $lib=$ligne["libT"];
      if (strlen($lib)>$ln) $lib=substr($lib,0,$ln).'...';
      if (strlen($lib)==0) $lib='* non saisi *';

      //echo '<td class="td'.$li.'"><a href="index.php?action=saisie&vers=1&numsitu='.$ref.'&v='.$commenter.'">'.$lib.'</a></td>';
      echo '<td class="td'.$li.'"><span id="'.$leStyle.'">'.$lib.'</span></td>';

      if ($valide=='O'){
          echo '<td class="td'.$li.'"><input type="submit" name="consult" value="Accéder" onClick="setSitu(1,'.$ref.')"/></td>';
          echo '<td class="td'.$li.'"><input type="submit" name="suppr" value="Supprimer" onClick="setSituSuppr(1,'.$ref.')"/></td>';
          echo '<td class="td'.$li.'">&nbsp;</td>';
      } else{
          echo '<td class="td'.$li.'"><input type="submit" name="suppr" value="Récupérer" onClick="setSituSuppr(2,'.$ref.')"/></td>';
          echo '<td class="td'.$li.'"><input type="submit" name="suppr" value="Détruire" onClick="setSituSuppr(3,'.$ref.')"/></td>';
      }

      if ($commentaire>0)
        echo '<td class="td'.$li.'">Comment&eacute;e ('.$commentaire.')</td>';
      else
        echo '<td class="td'.$li.'">&nbsp;</td>';

      if ($activ>0)
        echo '<td class="td'.$li.'">Activit&eacute; ('.$activ.')</td>';
      else
        echo '<td class="td'.$li.'">&nbsp;</td>';

      if ($prod>0)
        echo '<td class="td'.$li.'">Production ('.$prod.')</td>';
      else
        echo '<td class="td'.$li.'">&nbsp;</td>';

      if ($li==1) $li=2; else $li=1;
      echo '</tr>';
    }
  ?>
</table>
<?php echo '</form>'; ?>
</div>
