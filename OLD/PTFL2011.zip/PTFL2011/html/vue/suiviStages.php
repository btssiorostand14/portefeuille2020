<?php  include_once 'exit.php';   ?>
<div id="corps">

 <h2>Tableaux</h2>
  <p>Cette page permet d'affecter les stages des &eacute;tudiants aux professeurs en charge du suivi et
    de suivre l'alimentation des carnets de bord des &eacute;tudiants de la promotion s&eacute;lectionn&eacute;e.
  </p>

<?php 
  $eleves=$data["liste"]; 
  $stages=$data["stages"];
  $suivi=$data["suivi"];
  $profs=$data["profs"];
  	
    echo '<table cellspacing="0" >';
    echo '<tr><th>Etudiant</th><th>Référent</th><th>Entreprise</th><th>Tuteur</th><th>Carnet<br/>de bord</th></tr>';
    $li=1;$i=1;
    foreach($eleves as $eleve){  
      echo '<tr><td class="td'.$li.'">'.$eleve["nom"]." ".$eleve["prenom"].'</td>'; 
      echo '<td class="td'.$li.'"><form name="frmAffectation" action="index.php" method="POST">';
  	      //données d'interaction pour le traitement du formulaire
	  echo '<input type="hidden" name="action" value="suiviStage" />';
      echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
      echo '<input type="hidden" name="etud" value="'.$eleve["num"].'"/>';
      echo '<div class="centrer">';
       //liste des professeurs pour chaque stage
      	  if (isset($suivi[$i][0]["referent"])) $numProf=$suivi[$i][0]["referent"]; else $numProf=0;
      	   echo '<select name="lprofs"><option>Choisir</option>';
	       foreach($profs as $prof) {
	         if (isset($suivi[$i][0]["idProf"])) $numProf=$suivi[$i][0]["idProf"]; else $numProf=0;
	       	 echo '<option value="'.$prof["num"].'"';
	       	 if ($numProf==$prof["num"]) echo ' SELECTED';
	       	 echo '>'.$prof["libelle"].'</option>';
	       }
	       echo '</select>';
	  echo '<input type="submit" name="enregistrer" value="Affecter"/></div> </form>';
      echo '</td>';
      if (isset($stages[$i][0])) {
         $entreprise=$stages[$i][0]["Entreprise"];
         $tuteur=$stages[$i][0]["Tuteur"];         
         $liensuivi='index.php?action=carnetBord&annee='.$data["annee"].'&mode=prof&eleve='.$stages[$i][0]["idEtud"]; } 
      else {$liensuivi="";$entreprise="";$tuteur="";}
      echo '<td class="td'.$li.'">'.$entreprise.'</td>';
      echo '<td class="td'.$li.'">'.$tuteur.'</td>';
	  echo '<td class="td'.$li.'">';
	  if ($liensuivi!="") {echo '<a href="'.$liensuivi.'" target="_blank">carnet de bord</a>';};	 
      echo '</td></tr>';
      if ($li==1) $li=2; else $li=1; //couleur des lignes
      $i++;
    }
    
?>
</table>
</div>