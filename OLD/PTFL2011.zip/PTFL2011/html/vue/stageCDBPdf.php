<?php 
function afficheTableauTaches($pLesTaches, $pLesDomaines, $pLesJours) {
	//affiche un tableau  restituant les taches  pour cette semaine
	echo '<table border="1"><tr><th>Jour<th>Domaine<th>Dur&eacute;e <br/>(en h)<th>Description';
	foreach ($pLesTaches as $tache) {
		echo'<tr><td>'.getLejour($pLesJours,$tache["jour"]).'<td>'.getLeDomaine($pLesDomaines,$tache["idDomaine"]);
		echo '<td>'.$tache["duree"].'<td>'.$tache["description"]; 
	}
	echo '</table>';
}
function getLeDomaine($pLesDomaines,$pIdDomaine) {
	$i=0;
	while ($pLesDomaines[$i]["id"]!=$pIdDomaine) {$i++;};
	return $pLesDomaines[$i]["libelle"];
}
function getLeJour($pLesJours,$pIdJour) {
	$i=0;
	while ($pLesJours[$i]["code"]!=$pIdJour) {$i++;};
	return $pLesJours[$i]["libelle"];
}
?>
<meta charset="utf-8"/>

<style>
div {
		font-size: 13px;
		margin-bottom: 5px;
		margin-top: 5px;
		border: 0px;
	}
	
.cadre {
		border: 1px solid black;
		margin-bottom: 5px;
		font-size: 13px;
	}
	
.petit {
		font-size: 8px;
	}
	
.right { 
		text-align: right;
	}
	
.centre {
		margin-left: 50px;
		margin-right: 50px;
		text-align: center;
	}
	
h1 {
		text-align: center;
		font-size: 16px;
	}
	
h2 {
		text-align: center;
		font-size: 14px;
	}

body {
		font-family: Arial;
	}


div.breakafter {
  page-break-after: always;
}
</style>

<div>

<div class="right"><h1>CARNET DE BORD DE STAGE </h1><h2>Semaine : <?php echo $numeroSemaine; ?></h2></div>
<div class="cadre">
	<table><tr>	<td width="400px" valign="top"><h1>STAGIAIRE</h1><?=$nomEleve?>&nbsp;<?=$prenomEleve?></b><td><h1>Organisme d'acccueil</h1>
	<p><?=$nomOrganisme?><br/><?=$adresseOrganisme?> </p>
	</table>
</div>
<div><?php afficheTableauTaches($lesTaches, $lesDomaines, $lesJours);?></div>


</div>



