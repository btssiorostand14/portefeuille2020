<?php
  if (!$data["auth"]) exit("By pass!");
?>
