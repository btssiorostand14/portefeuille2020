<meta charset="utf-8"/>

<style>
div {
		font-size: 13px;
		margin-bottom: 5px;
		margin-top: 5px;
		border: 0px;
	}
	
.cadre {
		border: 1px solid black;
		margin-bottom: 5px;
		font-size: 13px;
	}
	
.petit {
		font-size: 8px;
	}
	
.right { 
		text-align: right;
	}
	
.centre {
		margin-left: 50px;
		margin-right: 50px;
		text-align: center;
	}
	
h1 {
		text-align: center;
		font-size: 16px;
	}
	
h2 {
		text-align: center;
		font-size: 14px;
	}

body {
		font-family: Arial;
	}


div.breakafter {
  page-break-after: always;
}
</style> 

<div>
<div class="cadre">

<table><tr><td width="400px"><h1>SITUATION </h1><h2><?php echo $situation[0]["libcourt"]; ?></h2>
	<td align="center"><h1>ETUDIANT.E</h1><h2><?=$nomEleve?>&nbsp;<?=$prenomEleve?></h2>
	<tr><td colspan="2"><h2>Activité du 
	<?php echo $situation[0]["datedebut"];?> au 
	<?php echo $situation[0]["datefin"];?> 
	</h2>
</table>
<?php 
	echo '<br/><b>Contexte : </b>'.$situation[0]["contexte"];
	echo "<br/><b>Besoin : "."</b>".$situation[0]["descriptif"]; 
	echo "<br/><b>Environnement : "."</b>".$situation[0]["environnement"];
	echo "<br/><b>Moyens : "."</b>".$situation[0]["moyen"]."<br/><br/>";
		echo '<table border="1"><tr><th colspan="2">Travail réalisé';
		foreach ($activites as $uneActiv) {
			echo "<tr><td>".$uneActiv["nomenclature"]." | ".$uneActiv["libelle"];
			echo "<td><b>".$uneActiv["commentaire"]."</b>";
		}
		echo "</table>";

?></div>

</div>



