
<div id="corps">
  <h2>Sauvegarde de la base de donn&eacute;es</h2>
  <p>Sept scripts (maximum) SQL de sauvegarde compress&eacute;e (.gz) sont conserv&eacute;s avec comme suffixe
   le num&eacute;ro du jour de la semaine (1=lundi ; 7=dimanche)</p>
  <p>La base de donn&eacute;es compl&egrave;te a &eacute;t&eacute; sauvegard&eacute;e dans l'espace de publication :</p>
  <p><?php echo $data["nomfic"]; ?></p>
  </div>
