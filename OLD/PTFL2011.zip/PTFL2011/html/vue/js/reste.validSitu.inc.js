
function setSitu(pMode, pSitu) {
	//demande confirmation puis enregistre les informations
	document.consultSitu.numsitu.value=pSitu; 
	document.consultSitu.mode.value=pMode;
	document.consultSitu.action.value="saisie";
	document.consultSitu.submit();
}

function setSituSuppr(pMode, pSitu) {
	//demande confirmation puis enregistre les informations
	document.consultSitu.numsitu.value=pSitu; 
	document.consultSitu.mode.value=pMode;
	document.consultSitu.action.value="gestion";
	document.consultSitu.submit();
}


