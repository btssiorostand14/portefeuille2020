
var change=false;

function reste(v,d){
  if (change) {
    document.frmSitu.modif.value='o';
  }
  if (verif()){
	  document.frmSitu.vers.value=v;
	  document.frmSitu.depuis.value=d;
	  document.frmSitu.submit();
  }
}

function resteSemaine(v,d){
  if (change) {
    document.frmTaches.modif.value='o';
  }
  if (verif()){
	  document.frmTaches.vers.value=v;
	  document.frmTaches.depuis.value=d;
	  document.frmTaches.submit();
  }
}
