

function resteSemaine(v,d){
  if (change) {
    document.infoStage.modif.value='o';
  }
  if (verif()){
	  document.infoStage.semaine.value=v;
	  //document.infoStage.depuis.value=d;
	  document.infoStage.submit();
  }

}

function setSemaine(pSemaine) {
   document.infoStage.semaine.value=pSemaine;
   document.infoStage.modif.value='n'; //ne prend pas en compte les saisies
   document.infoStage.submit();
}

function setTache(pTache, pLigne) {
	//définit la tâche dans la base et la ligne dans l'interface concernées par MAJ ou suppression
	document.infoStage.latache.value=pTache; 
	document.infoStage.tachemodif.value=pLigne;
	document.infoStage.submit();
}

function setTacheSuppr(pTache, pLigne) {
	//demande confirmation puis enregistre les informations
	document.infoStage.modif.value=confirm("Cette tâche sera définitivement supprimée");
	setTache(pTache, pLigne);
}



