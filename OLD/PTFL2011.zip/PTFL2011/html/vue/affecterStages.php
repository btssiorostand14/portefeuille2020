<?php  include_once 'exit.php'; 

  $affich=$_GET["aff"];
  ?>
<div id="corps">

 <h2>Tableaux</h2>
  <p>Cette page permet 
  <?php   if ($affich=="affect")  {?>
  	d'affecter les stages des &eacute;tudiants de votre promotion aux professeurs en charge du suivi
  <?php  }
   else {
  ?>
    de suivre l'alimentation des carnets de bord des &eacute;tudiants de la promotion s&eacute;lectionn&eacute;e.
  </p>

<?php 
    }

  $eleves=$data["liste"]; 
  $stages=$data["stages"];
  $suivi=$data["suivi"];
  if ($affich=="affect") {
  	echo '<form name="frmAffectation" action="index.php" method="POST">';
  }
    echo '<table cellspacing="0" >';

    echo '<tr><th>Etudiant</th><th>Référent</th><th>Entreprise</th><th>Tuteur</th><th>Carnet de bord</th></tr>';
    $li=1;$i=1;
    foreach($eleves as $eleve){  
      echo '<tr><td class="td'.$li.'">'.$eleve["nom"]." ".$eleve["prenom"].'</td>'; 
      echo '<td class="td'.$li.'">';
     	 if (isset($suivi[$i][0]["referent"])) echo $suivi[$i][0]["referent"];
      echo '</td>';
      if (isset($stages[$i][0])) { // il y a un stage, on valorise les contenus
         $entreprise=$stages[$i][0]["Entreprise"];
         $tuteur=$stages[$i][0]["Tuteur"];         
         $liensuivi='index.php?action=carnetBord&annee='.$_GET["annee"].'&mode=prof&eleve='.$stages[$i][0]["idEtud"]; } 
      else {$liensuivi="";$entreprise="";$tuteur="";}
      echo '<td class="td'.$li.'">'.$entreprise.'</td>';
      echo '<td class="td'.$li.'">'.$tuteur.'</td>';
	  echo '<td class="td'.$li.'">';
	  if ($affich=="affect") {
	       echo '<select name="lprofs".$i>';
	       /*foreach($profs as $prof) {
	       	
	       }*/
	       echo '</select>';
	  }
	  else { if ($liensuivi!="") {echo '<a href="'.$liensuivi.'" target="_blank">carnet de bord</a>';};
	  }
	 
      echo '</td></tr>';
      if ($li==1) $li=2; else $li=1; //couleur des lignes
      $i++;
    }
    
?>
<!--
<form method="post" action="index.php">
    <?php
      echo '<input type="hidden" name="action" value="suiviStage" />';
    ?>
    <h3>SUIVI DES STAGES DE LA SECTION</h3>
	

</form>
-->
</table>
</div>
<?php  if ($affich=="affect") { ?>
  	<div class="centrer"><span class="oblig">*</span> champ obligatoire<input type="submit" name="enregistrer" value="Enregistrer la semaine"></div>
  </form>
  <?php } ?>