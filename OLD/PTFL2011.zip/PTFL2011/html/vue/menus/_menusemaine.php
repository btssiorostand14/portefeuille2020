<?php

//définit un nombre d'onglets en fonction du nombre de semaines
for($i=0;$i<=$data["nbSemaines"];$i++){
  if ($semaine==$i)
    echo '<li id="active"><a href="#" id="current">';
  else
    echo '<li>   <a href="#" onclick="resteSemaine('.$i.",".$semaine.');">';
  
  if($i==0) 
  		echo 'Infos stage</a></li>';
  else 
  	echo 'Semaine '.$i.'</a></li> ';
}
?>
