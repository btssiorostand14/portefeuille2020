<?php

//définit un nombre d'onglets en fonction du nombre de semaines
//$semaine=$get("semaine");
for($i=0;$i<=$data["nbSemaines"];$i++){
  if ($semaine==$i)
    echo '<li id="active"><a href="#" id="current">';
  else
    echo '<li>   <a href="#" onclick="setSemaine('.$i.');">';
  
  if($i==0) 
  		echo 'Infos stage</a></li>';
  else 
  	echo 'Semaine'.$i.'</a></li> ';	
}
 //onglet pour les avis sur le stage
  if ($semaine==$i) {
    echo '<li id="active"><a href="#" id="current">';
    if ($nouveau) echo '<span class="rouge">Echange</span>'; else echo 'Echange';
    echo '</a></li>';}
  else
    {echo '<li><a href="#" onclick="setSemaine('.$i.');">';
    if ($nouveau) echo '<span class="rouge">Echange</span>'; else echo 'Echange';
    echo '</a></li>';}
  $i++;
  //onglet pour les attestations
  if ($semaine==$i)
    echo '<li id="active"><a href="#" id="current">Attestation</a></li>';
  else
    {echo '<li>   <a href="#" onclick="setSemaine('.$i.');">';
    echo 'Attestation</a></li>';}
?>
