<div class="menuh">
<h4><a href="index.php?action=eaccueil&q=e">Espace &eacute;tudiant</a></h4>
</div>

<div class="menu">
<h4><a href="javascript:aide('e',1)">Pilotage</a></h4>
<ul>
<?php 
    echo '<li><a href="index.php?action=tableauBord">Tableau de bord</a></li>';
    echo '<li><a href="index.php?action=notification">Notifications</a></li>';
?>
</ul>
</div>

<div class="menu">
<h4><a href="javascript:aide('e',1)">Situation professionnelle</a></h4>
<ul>
<?php
    echo '<li><a href="index.php?action=saisie">Nouvelle situation</a></li>';
    echo '<li><a href="index.php?action=gestion&t=s">Gestion situations</a></li>';
?>
</ul>
</div>

<div class="menu">
<h4><a href="javascript:aide('e',4)">Stages</a></h4>
<ul>
<?php
    echo '<li><a href="index.php?action=carnetBord&annee=1">Carnet de bord 1&egrave; ann&eacute;e</a></li>';
    echo '<li><a href="index.php?action=carnetBord&annee=2">Carnet de bord 2&egrave; ann&eacute;e</a></li>';
    echo '<li><a href="index.php?action=terrainsStages">Infos anciens stages</a></li>';
?>
</ul>
</div>

<div class="menu">
<h4><a href="javascript:aide('e',2)">Synth&egrave;se</a></h4>
<ul>
<?php
    echo '<li><a href="index.php?action=bilan">Bilan individuel</a></li>';
    echo '<li><a href="index.php?action=synthese" target="_blank">Tableau de synth&egrave;se</a></li>';
    echo '<li><a href="index.php?action=syntheseExcel">Tableur Excel</a></li>';
?>
</ul>
</div>


 
<div class="menu">
<h4><a href="javascript:aide('e',3)">Divers</a></h4>
<ul>
<?php
    echo '<li><a href="https://wiki.sio.bts/doku.php" target="_blank" >Wiki section (interne)</a></li>';
    echo '<li><a href="https://wiki.inforostand14.net/doku.php" target="_blank" >Wiki section (externe)</a></li>';
    echo '<br/><li><!-- <a href="index.php?action=sauve"> -->Sauvegarde<!--/a--></li>';
    if ($data["droit"]) {  //etudiant
      echo '<li><a href="index.php?action=modif">Param&egrave;tres</a></li>';
      echo '<br />';
      echo '<li><a href="mailto:'.$data["lien"].'?subject=[portefeuille]">Contact admin</a></li>';
    }
?>


</ul>
</div>
