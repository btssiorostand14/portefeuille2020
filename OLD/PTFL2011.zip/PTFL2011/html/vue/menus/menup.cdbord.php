<div class="menu">
<h4><a href="javascript:aide('p',2)">Suivi des stages</a></h4>
<ul>
<?php
  if ($data["droit"]) //prof
    
    //echo '<li><a href="index.php?action=suiviStage&aff=affect">Affectation des stages</a></li>';
     echo '<li><a href="index.php?action=suiviStage&aff=suivi&annee=1">Carnets de bord TS1</a></li>';
    echo '<li><a href="index.php?action=suiviStage&aff=suivi&annee=2">Carnets de bord TS2</a></li>';

?>
</ul>
</div>

