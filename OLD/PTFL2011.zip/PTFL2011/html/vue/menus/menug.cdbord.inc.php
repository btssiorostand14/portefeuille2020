<div class="menu">
<h4><a href="javascript:aide('e',4)">Stages</a></h4>
<ul>
<?php
    echo '<li><a href="index.php?action=carnetBord&annee=1">Carnet de bord 1&egrave; ann&eacute;e</a></li>';
    echo '<li><a href="index.php?action=carnetBord&annee=2">Carnet de bord 2&egrave; ann&eacute;e</a></li>';
?>
</ul>
</div>
