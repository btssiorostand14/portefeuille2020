<?php
  //include_once 'exit.php';
  if ($commenter=="N"){
  	echo '<div class="centrer">';
  	echo '<span class="oblig">*</span> champ obligatoire ';
  	echo '<input type="submit" name="enregistrer" value="Enregistrer" /></div>';
  }
?>

