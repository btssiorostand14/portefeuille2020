<?php  include_once 'exit.php'; 
 function listeDeroul($pnomlist, $pchampoption, $pchampaffich, $pdatas){
echo '<select name="'.$pnomlist.'"><option></option>';
foreach ($pdatas as $unedata){
	echo '<option value="'.$unedata[$pchampoption].'">'.$unedata[$pchampaffich].'</option>';
	}
echo '</select>';
}
?>
<div id="corps">
<h1>Critères de recherche</h1>
Sélectionnez un critère de sélection :
<form name="criteres" action="index.php" method="post">
<input type="hidden" type="text" value="terrainsStages" name="action" />
<br/>Par département : <?php listeDeroul("dept","dept","dept",$data["departements"]); ?>
<br/>Par année : <?php listeDeroul("annee","anneeStage","anneeStage",$data["annees"]); ?>
<br/>Par ville : <?php listeDeroul("ville","ville","ville",$data["villes"]); ?>
<input type="submit" value="filtrer" />
</form>
<hr>
<h1> Liste des anciens stages </h1>
<table border="1"><tr><th>Entreprise</th><th>Année<br/>du stage</th><th>Promotion</th><th>Avis sur<br/>le stage</th></tr>
<?php 
 foreach($data["terrains"] as $leStage) {
 	echo '<tr><td>'.$leStage["nomentreprise"].'<br/>'.$leStage["codepostal"].' '.$leStage["ville"].'<td>'.$leStage["anneeStage"].'<td>';
 	echo 'TS'.$leStage["codesource"].'-'.$leStage["promo"].'<td>'.$leStage["avis"].'</tr>';
 }
?>
</table>
</div>
  