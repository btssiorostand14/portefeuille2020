<div id="corps">
<?php
  include_once 'situencours.php';
?>
<div id="navcontainer">
<ul id="navlist">

<?php
$vers=5;
include_once './vue/menus/menusaisie.php';

?>

</ul>
</div>

<script type="text/javascript">
 <?php
   include "./vue/js/reste.js";
   include "./vue/js/verif.js";
 ?>
</script>

<form name="frmSitu" method="post" action="index.php" onsubmit="return verif();">

    <?php
      echo '<input type="hidden" name="action" value="saisie" />';
      echo '<input type="hidden" name="depuis" value="'.$vers.'" />';
      echo '<input type="hidden" name="modif" value="n" />';
      echo '<input type="hidden" name="vers" value="'.$vers.'" />';
      echo '<input type="hidden" name="frm" value="enreg" />';

      echo '<input type="hidden" name="numsitu" value="'.$numsitu.'" />';
      echo '<input type="hidden" name="commenter" value="'.$commenter.'" />';

      if ($numsitu!=0){
          $lescomm=$data["lescomm"];
          $idprof=$data["idprof"];
          $nb=count($lescomm);//nombre de commentaires
      } else $nb=0;

      $lgc=100; //largeur des controles de la page
      $nbl=3; //nombre lignes des textarea
	  echo '<div class="titre">Les commentaires &eacute;crits par les professeurs sur cette situation sont
 	     pr&eacute;sent&eacute;s par ordre chronologique d&eacute;croissant :</div>';

      foreach ($lescomm as $ligne) {
         echo '<div class="activ">'.$ligne["datecommentaire"].'  '.$ligne["prenomprof"].' '.$ligne["nomprof"];
         if ($ligne["numprof"]==$idprof){
          	echo ' - (supprimer commentaire : ';
            echo '<input type="checkbox" name="chksup[]" value="'.$ligne["numero"].'" /> )</div>';
          	echo '<input type="hidden" name="commref[]" value="'.$ligne["numero"].'" />';
          	echo '<textarea rows="'.$nbl.'"  cols="'.$lgc.'" name="comm[]">';
          }
          else
          	echo '</div><textarea rows="'.$nbl.'"  cols="'.$lgc.'" disabled="disabled">';
          echo $ligne["commentaire"];
          echo '</textarea>';
     	}
     	if ($commenter=="P"){//pour profs
	     	echo '<div class="activ">Votre commentaire : </div>';
	          echo '<textarea rows="'.$nbl.'"  cols="'.$lgc.'" name="commnew">';
	          echo '</textarea>';

	       	echo '<div class="centrer">';
	  		echo '<span class="oblig">*</span> champ obligatoire ';
	  		echo '<input type="submit" name="enregistrer" value="Enregistrer" /></div>';
     	}
    ?>
  </form>
  
  <?php if ($data["lasitu"][0]["valideeProf"]!="1") {
  			if ($commenter=="P"){//pour profs
  			echo '<form name="frmValidSitu" id="frmValidSitu" action="index.php">';
  			echo '<input type="hidden" name="action" value="saisie" />';
     		echo '<input type="hidden" name="depuis" value="'.$vers.'" />';
     		echo '<input type="hidden" name="modif" value="o" />';
     		echo '<input type="hidden" name="vers" value="'.$vers.'" />';
      		echo '<input type="hidden" name="frm" value="valid" />';
      		echo '<input type="hidden" name="numsitu" value="'.$numsitu.'" />';      	
      		echo '<input type="hidden" name="commenter" value="'.$commenter.'" />';
     		echo '<br/><div class="centrer">';      	
	  		echo '<input type="submit" name="signaler" value="Signaler les commentaires" />';   	
	  		echo '<input type="submit" name="valider" value="Viser la situation" /></div>';
     		echo '</form>';}
     		else { //possibilité de signalement pour un étudiant
     		if ($data["lasitu"][0]["informProf"]==0) {//la situation n'a pas été informée
     		echo '<form name="frmInformer" id="frmInformer" action="index.php">';
     		echo '<input type="hidden" name="action" value="saisie" />';
     		echo '<input type="hidden" name="depuis" value="'.$vers.'" />';
     		echo '<input type="hidden" name="modif" value="o" />';
     		echo '<input type="hidden" name="vers" value="'.$vers.'" />';
      		echo '<input type="hidden" name="frm" value="inform" />';
      		echo '<input type="hidden" name="numsitu" value="'.$numsitu.'" />';      	
      		echo '<input type="hidden" name="commenter" value="'.$commenter.'" />';
      		echo '<div class="centrer"><select name="prof">';
      		foreach ($data["lesProfs"] as $prof) {
      			echo '<option value='.$prof["num"].'>'.$prof["libelle"].'</option>';
      		}
      		echo '</select>';
      		echo '<input type="submit" name="informer" value="Informer un(e) prof" />';  
     		echo '<br/></div>';      	
     		echo '</form>';
     		}
     		else {
     			echo '<span id="situinform">Un enseignant est informé de la situation</span>';
     		}
     		}
     		}
     	else {echo '<div class="centrer"><span id="situvisee">Cette situation a été visée par les professeurs</span></div>';}
     	
  ?>
  

