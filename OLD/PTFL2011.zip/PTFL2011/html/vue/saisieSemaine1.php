<div id="corps">

<?php echo '<span id="situtete"><br/>'.$data["nomEtud"].'</span>'; ?>
<div id="navcontainer">
<ul id="navlist">

<?php
$semaine=$data["semaine"];	
function lesJours($lesJours,$pNomListe, $pSelection) {
	$listeJours='<select name="'.$pNomListe.'">';
	foreach ($lesJours as $leJour) {
		$listeJours.='<option value="'.$leJour["code"].'"';
		if ($leJour["code"]==$pSelection) $listeJours.=' selected';
		$listeJours.='>'.$leJour["libelle"].'</option>';
	}
	$listeJours.='</select>';
	return $listeJours;
}
function lesDomaines($pLesDomaines, $pNomListe, $pSelection) {
 	$listeDomaines='<select name="'.$pNomListe.'"> ';
    	foreach ($pLesDomaines as $item) {
        	$listeDomaines.='<option value="'.$item["id"].'"';
        	if ($item["id"]==$pSelection) $listeDomaines.=' selected';
    		$listeDomaines.='>'.$item["libelle"].'</option>';
        }
	$listeDomaines.='</select>';
	return $listeDomaines;
}
function afficheTableauTaches($pLesTaches, $pLesDomaines, $lesJours) {
	//affiche un tableau permettant la saisie d'une nouvelle tache et restituant les taches passées pour cette semaine
  
	
	echo '<table id="tachesPassees" border="1" cellspacing="0" name="ajoutTaches"><tr><th>Jour</th><th>Domaine</th><th><span class="oblig">*</span>Dur&eacute;e <br/>(en h)</th><th><span class="oblig">*</span>Description</th><th></th></tr>';
	//zone pour la saisie d'une nouvelle tâche  
	echo '<tr><td>'.lesJours($lesJours,"jour","1Lu").'</td><td>'.lesDomaines($pLesDomaines,"domaine","Adm").'
			</td><td><input type="text" name="duree" size="2" class="champOblig"/></td>
	   		<td><textarea cols="40" rows="3" maxlength="255" name="descr" class="champOblig"></textarea></td><td><input type="submit" name="enregistrer" value="Enregistrer la tâche" onclick="return verif();submit();"></td></tr>';
	$numTache=1;
	//tâches issues de la base
	foreach ($pLesTaches as $tache) {
		echo'<tr><td>'.lesJours($lesJours,"jour".$numTache,$tache["journee"]).'</td><td>'.lesDomaines($pLesDomaines,"domaine".$numTache,$tache["idDomaine"]).'</td>';
		echo '<td><input type="text" name="duree'.$numTache.'" size="2" value="'.$tache["duree"].'"/></td><td><textarea maxlength="255" cols="40" rows="3" name="descr'.$numTache.'">'.$tache["description"].'</textarea></td>';
		echo '<td><div class="centrer"><input type="submit" name="maj" onClick="setTache('.$tache["id"].','.$numTache.')" value="MàJ"';
		echo '><input type="submit" name="suppr" onClick="setTacheSuppr('.$tache["id"].','.$numTache.')" value="DEL"></div></td></tr>';
		$numTache++;
	}
	echo '</table>';
}

include_once './vue/menus/menusemaine.php';//gere les onglets

?>

</ul>
</div>

<script type="text/javascript">
 <?php
   include "./vue/js/reste.js";
   include "./vue/js/verif.js";
 ?>

</script>

<h2>Activité Quotidienne</h2>
<form name="infoStage" id="infoStage" method="post" action="index.php" >

<?php  //formulaire des tâches
      echo '<input type="hidden" name="action" value="carnetBord2" />';
      echo '<input type="hidden" name="modif" value="n" />';
     // echo '<input type="hidden" name="depuis" value="'.$semaine.'" />';      
      echo '<input type="hidden" name="semaine" value="'.$semaine.'" />';      
      echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
      echo '<input type="hidden" name="carnet" value="'.$data["carnet"].'" />';
      echo '<input type="hidden" name="form" value="taches"/>';
      echo '<input type="hidden" name="latache" value="0"/>';
      echo '<input type="hidden" name="tachemodif" value="0"/>';
      echo '<input type="hidden" name="eleve" value="'.$data["eleve"].'" />';

      if (isSet($data["taches".$semaine]))  afficheTableauTaches($data["taches".$semaine], $domaines=$data["domaine"], $data["jours"]);
if (!(isset($_GET["mode"]))) {?>
    <div class="centrer"><span class="oblig">*</span> champ obligatoire</div>
<?php } ?>
  </form>
  
<hr/><br/>
<h2>Bilan de la semaine</h2>
<form name="infoBilan" id="infoBilan" method="post" action="index.php"> 
<?php   //formulaire du bilan
      echo '<input type="hidden" name="action" value="carnetBord2" />';
      echo '<input type="hidden" name="modif" value="n" />';
     // echo '<input type="hidden" name="depuis" value="'.$semaine.'" />';      
      echo '<input type="hidden" name="semaine" value="'.$semaine.'" />';      
      echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
      echo '<input type="hidden" name="carnet" value="'.$data["carnet"].'" />';
      echo '<input type="hidden" name="form" value="bilan"/>';
       echo  '<div class="libellebas">Apprentissages : </div>';
       echo '<div class="champtexte"><textarea cols="70" rows="3" maxlength="255" name="apprent" >'.$data["laSemaine"]["apprentissage"].'</textarea></div>';
       echo '<div class="libellebas">Bilan et difficultés : </div>';
       echo '<div class="champtexte"><textarea cols="70" rows="3" maxlength="255" name="bilan" >'.$data["laSemaine"]["bilan"].'</textarea></div><br/>';
 if (!(isset($_GET["mode"]))) {?>    
      <div class="centrer"><input type="submit" name="enregistrer" value="Enregistrer le bilan"></div>
 <?php } ?>  </form>

 </div> 