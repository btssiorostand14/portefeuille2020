<?php  include_once 'exit.php'; ?>

<script type="text/javascript">
 <?php
   include "./vue/js/reste.js";
   include "./vue/js/verif.js";
 ?>
</script>
<?php function carnetBord($pAnnee, $pCarnets) {
	//affiche les statistiques des carnets de bord pour les TS1 ou TS2
	//sépare les deux parties du tableau résultat 
	echo '<hr><h2>Statistiques des carnets de bord TS'.$pAnnee.'</h2>';
	$carnets=$pCarnets["carnets"];
	$stats=$pCarnets["stats"];
	echo '<table border="1"><tr><th>Etudiant.e</th><th>Activités par semaine</th></tr>';
	for ($i=0;$i<count($carnets);$i++) {
		//pour chaque ligne de l'année demandée, affiche le nom de l'étudiant et son alimentation
		$leCarnet=$carnets[$i];
		echo '<tr>';
		if ($leCarnet["codeSource"]==$pAnnee) {
			echo '<td><a href="index.php?action=carnetBord&annee='.$pAnnee.'&mode=prof&eleve='.$leCarnet["numEtud"].'">'.$leCarnet["nomEtud"].'</a></td>';
			echo '<td><table border=1><tr>';
			//affiche les statistiques par semaine remplie
			for ($j=0;$j<count($stats[$leCarnet["id"]]);$j++) {
				echo '<td width="2">'.$stats[$leCarnet["id"]][$j]["nbActivites"].'</td>';
			}
			echo '</tr></table>';
		}
	echo '</tr>';
	}
	echo '</table>';
}

function carnetsBordEtud($pCarnets){
	//affiche les statistiques des carnets de bord TS1 et TS2
	echo '<hr><h2>Statistiques des carnets de bord </h2>';
	$carnets=$pCarnets["carnets"];
	$stats=$pCarnets["stats"];
	echo '<table border="1"><tr><th>Ann&eacute;e</th><th>Activités par semaine</th></tr>';
	for ($i=0;$i<count($carnets);$i++) {
		//pour chaque ligne de l'année demandée, affiche le nom de l'étudiant et son alimentation
		$leCarnet=$carnets[$i];
		echo '<tr>';
		echo '<td>TS'.$leCarnet["codeSource"].'</td>';
		echo '<td><table border=1><tr>';
		//affiche les statistiques par semaine remplie
		for ($j=0;$j<count($stats[$leCarnet["id"]]);$j++) {
			echo '<td width="2">'.$stats[$leCarnet["id"]][$j]["nbActivites"].'</td>';
		}
		echo '</tr></table>';
		echo '</tr>';
	}
	echo '</table>';
}

function statsPortefeuille($pSituations){
	//affiche les les situations à commenter destinées au professeur connecté
  	echo "<hr><h2>Siutations signalées par les étudiant.e.s</h2>";
  	echo '<table border="1"><tr><th>Etudiant.e<th>Situations &agrave commenter</th></tr>';
  		$ligne='';
  		for($sit=0;$sit<count($pSituations);$sit++) {//ajoute les liens vers les situation à commenter
  			echo '<tr><td>'.$pSituations[$sit]["nomEtud"];
  			echo '<td><a href="index.php?action=saisie&vers=1&numsitu='.$pSituations[$sit]["ref"].'&commenter=P">'.$pSituations[$sit]["libcourt"].'</a>';
  			echo '</tr>';
		}
  	echo '</table>';
}

function situsSignalees($pSituations){
	//affiche les les situations signalées par un.e professeur poru l'étudiant.e connecté.e
  	echo "<hr><h2>Siutations signalées par les enseignant.e.s</h2>";
  	echo '<table border="1"><tr><th>Situations &agrave &eacute;tudier</th><th></th></tr>';
  		$ligne='';
  		for($sit=0;$sit<count($pSituations);$sit++) {//ajoute les liens vers les situation à commenter
  			echo '<tr><td>'.$pSituations[$sit]["libcourt"].'</td><td>';
  			echo '<form name="consultSitu" id="consultSitu" method="post" action="index.php" >';
					//formulaire des tâches
      			echo '<input type="hidden" name="action" value="saisie" />';   
      			echo '<input type="hidden" name="vers" value="1" />';  
      			echo '<input type="hidden" name="mode" value="1" />';
      			echo '<input type="hidden" name="numsitu" value="'.$pSituations[$sit]["ref"].'" />';      
      			echo '<input type="hidden" name="t" value="s" />';
  				echo '<input type="submit" name="consult" value="Accéder"/></form></td>';
  			echo '</tr>';
		}
  	echo '</table>';
}



function notificationsProf($pNotifs, $pAcquitt) {
	//affiche les anciennes notifications
  	echo "<hr><h2>Notifications</h2>";
  	echo '<table border="1"><tr><th>Auteur.e</th><th>Sujet</th><th>Echéance</th><th>Promotion</th><th>Acquittements</th><th>Action</th></tr>';
  	foreach ($pNotifs as $notif) {
  		echo '<tr><td>'.$notif["nomProf"].' '.$notif["prenom"].'</td><td>'.$notif["sujet"].'</td><td>'.$notif["echeance"].'</td><td>'.$notif["nomGroupe"].'</td>';
  		echo '<td>';
  			if (isset($pAcquitt[$notif["id"]])) echo $pAcquitt[$notif["id"]]; else echo "0";
  		echo '</td>';
  		echo '<td rowspan="2"><form name="suppr" action="index.php" method="POST">';
  		  	echo '<input type="hidden" name="action" value="notification" />';
     		 echo '<input type="hidden" name="form" value="Suppr" />';
     		 echo '<input type="hidden" name="notif" value="'.$notif["id"].'" />';
     		 echo '<input type="submit" name="enregistrer" value="Effacer" />';
		echo '</form></td>';     		 
     	echo '</tr>';
  		echo '<tr><td colspan="5">'.$notif["libelle"].'</td></tr>';  		
  	}
  	echo '</table>';
}

function notificationsEtud($pNotifs){
	echo "<hr><h2>Notifications</h2>";
	echo '<table border="1"><tr><th>Auteur</th><th>Sujet</th><th>Echéance</th><th>Statut</th></tr>';
  	foreach ($pNotifs as $notif) {
  		echo '<tr';
  		if (!$notif["etat"]) echo ' bgcolor="FF6600"';
  		echo '><td>'.$notif["nom"].' '.$notif["prenom"].'</td><td>'.$notif["sujet"].'</td><td>'.$notif["echeance"].'</td>';
  		echo '<td rowspan="2">';
  		if ($notif["etat"]) { echo 'Acquitté';} 
  		else {echo '<form name="acquitter" action="index.php" method="POST">';
  			  echo '<input type="hidden" name="form" value="Acquit" />';
  			  echo '<input type="hidden" name="action" value="notification" />';
  			  echo '<input type="hidden" name="notif" value="'.$notif["id"].'" />';
  			  echo '<input type="submit" name="enregistrer" value="J\'ai lu" />';
  			  echo '</form>';}
  		echo '</td></tr>';
  		echo '<tr'; if (!$notif["etat"]) echo ' bgcolor="FF6600"'; echo '><td colspan="3">'.$notif["libelle"].'</td></tr>';
  		}
  	echo '</table>'; 
  	}

?>
<div id="corps">



<h1> Tableau de bord </h1>

<?php 
      //traitement en fonction du mois de l'année : 
      // janvier/février -> carnets de bord de TS2 / mai juin -> carnet de bord TS1
      //restant de l'année -> notifications et portefeuille
     
    if ($data["typeUtil"]=="P") {//tableau de bord prof
    	$date=date("m");
    	if ($date=="01" || $date=="02") { carnetBord(2,$data["carnets"]);  }
    	if ($date=="04" || $date=="05" || $date=="06") { carnetBord(1,$data["carnets"]); }
    	statsPortefeuille($data["situations"]);
    	notificationsProf($data["notifs"],$data["acquittements"]);
    }
    else { //tableau de bord étudiant.e
    	carnetsBordEtud($data["carnets"]);
    	situsSignalees($data["situations"]);
    	notificationsEtud($data["lesNotifications"]);
    }
  
?>
     
  
