<?php  include_once 'exit.php'; ?>

<script type="text/javascript">
 <?php
   include "./vue/js/reste.js";
   include "./vue/js/verif.js";
 ?>
</script>

<?php
function textarea($pDonnees, $pChamp, $pNom,$pClasse, $pOblig, $pLignes,$pColonnes, $pLongueur, $pTaille,$pLibelle,$pClassLib) {
	echo  '<div class="'.$pClassLib.'">'.$pLibelle; 
	   if ($pOblig) echo ' <span class="oblig">*</span> ';
	echo ': </div>';
	echo '<div class="'.$pClasse.'"><textarea rows="'.$pLignes.'" cols="'.$pColonnes.'"  ';
	if ($pOblig) echo ' class="champOblig"';
	echo ' maxlength="'.$pLongueur.'" name="'.$pNom.'"  size="'.$pTaille.'"  onchange="change=true;">'; 
    if (isset($pDonnees["stage"])) echo($pDonnees["stage"][$pChamp]);
    echo '</textarea></div>';
}

function zonetexte($pDonnees, $pChamp, $pNom,$pClasse, $pOblig,$pColonnes, $pLongueur, $pTaille, $pLibelle,$pClassLib) {
	echo  '<div class="'.$pClassLib.'">'.$pLibelle; 
	   if ($pOblig) echo ' <span class="oblig">*</span> ';
	echo ': </div>';
	echo '<div class="'.$pClasse.'"><input type="text" size="'.$pTaille.'" maxlength="'.$pLongueur.'"  cols="'.$pColonnes.'" name="'.$pNom.'" ';
    if ($pOblig) echo ' class="champOblig"';
    echo ' onchange="change=true;" ';        
    if (isset($pDonnees["stage"])) echo(' value="'.$pDonnees["stage"][$pChamp].'"');
    echo '/></div>';
}

?>

<div id="corps">
<?php echo '<span id="situtete"><br/>'.$data["nomEtud"].'</span>'; ?>
<div id="navcontainer">
	<ul id="navlist">
	<?php 	
	   $semaine=$data["semaine"];	
	   $nouveau=$data["nouveauMsg"]["nb"]>0;
      if ($data["carnet"]>0) include_once './vue/menus/menusemaine.php';//gere vers et depuis

?>
			</ul>
			</div>

<h1> Carnet de bord de stage 
	<?php 
		echo($data["annee"])."</h1>"; 
		if (isset($data["leReferent"])) echo "<h2>suivi par ".$data["leReferent"]."</h2>";		
	?> 
</h1>
<form name="infoStage" action="index.php" method="POST" onsubmit="return verif();">
<?php 	$lgc=60;
      //données d'interaction pour le traitement du formulaire
      echo '<input type="hidden" name="action" value="carnetBord" />';
      echo '<input type="hidden" name="modif" value="n" />';
      echo '<input type="hidden" name="depuis" value="'.$semaine.'" />';
      //echo '<input type="hidden" name="codeSource" value="'.$data["codesource"].'" />';
      echo '<input type="hidden" name="annee" value="'.$data["annee"].'" />';
      echo '<input type="hidden" name="semaine" value="'.$semaine.'" />';
      echo '<input type="hidden" name="eleve" value="'.$data["eleve"].'" />';
      echo '<input type="hidden" name="carnet" value="';
         if (is_array($data["stage"])) {echo $data["stage"]["id"];} else echo $data["stage"];
     echo '" />';
      
      //données du formulaire
		echo '<h2>Informations de l\'entreprise</h2><table border="0">';
		echo '<tr><td width="50%"> ';
		$lgc=35;		
		textarea($data, "nomentreprise", "entreprise", "champtexteb", true, 4, $lgc, 255, 35, "Entreprise", "libellebas");
		zonetexte($data,"adresseentreprise","adresse","champtexte",true,$lgc,255,35,"Adresse", "libellebas");
		zonetexte($data,"codepostal","cp","champtexte",true,$lgc,5,5,"Code postal", "libellebas");
		zonetexte($data,"ville","ville","champtexte",true,$lgc,255,35,"Ville", "libellebas");	
		zonetexte($data,"servicestage","service","champtexte",false,$lgc,255,35,"Service", "libellebas");
		echo '</td><td>' ;
		zonetexte($data,"directeur","directeur","champtexte",false,$lgc,90,35,"Directeur/trice", "libellebas");
		zonetexte($data,"codenaf","naf","champtexte",true,$lgc,5,5,"Code Naf", "libellebas");
		zonetexte($data,"siret","siret","champtexte",true,$lgc,20,20,"Siret", "libellebas");
		zonetexte($data,"telentreprise","telentreprise","champtexte",false,$lgc,14,14,"Téléphone entreprise", "libellebas");
		zonetexte($data,"faxentreprise","fax","champtexte",false,$lgc,14,14,"Télécopie (fax)", "libellebas");
		zonetexte($data,"melentreprise","melentreprise","champtexte",false,$lgc,255,35,"Mail entreprise", "libellebas");							
		echo '</td></tr></table><hr/><table><tr><td align="top" width="50%">';
		echo '<h2>Informations du stage</h2><p>Cette partie est à actualiser lors de l\'arrivée en entreprise</p>';
    	textarea($data, "lieu", "lieu", "champtexteb", false, 4, $lgc, 255, 35, "Lieu du stage", "libellebas");
        //informations du tuteur : nom, mail, téléphone, mobile
        textarea($data,"sujet","sujetStage","champtexte",true,3,$lgc,255,35,"sujet du stage", "libellebas");
        zonetexte($data,"coordonneesTut","tuteur","champtexte",true,$lgc,255,35,"Nom de tuteur/tutrice", "libellebas");
        zonetexte($data,"tutMail","tuteurmail","champtexte",false,$lgc,80,35,"Mail tuteur/trice", "libellebas");
        zonetexte($data,"tutTel","tuteurtel","champtexte",false,$lgc,14,14,"Tél tuteur/trice", "libellebas");
        zonetexte($data,"tutMobile","tuteurmob","champtexte",false,$lgc,14,14,"Mobile tuteur/trice", "libellebas");
        echo '</td><td>--------------Horaires----------------<br/>   Par défaut, 8-12 / 14-17 : à renseigner si différent'; 
        zonetexte($data,"horLun","horLundi","champtexte",false,$lgc,80,35,"Lundi", "libellebas");
        zonetexte($data,"horMar","horMardi","champtexte",false,$lgc,80,35,"Mardi", "libellebas");
        zonetexte($data,"horMer","horMercredi","champtexte",false,$lgc,80,35,"Mercredi", "libellebas");
        zonetexte($data,"horJeu","horJeudi","champtexte",false,$lgc,80,35,"Jeudi", "libellebas");
        zonetexte($data,"horVen","horVendredi","champtexte",false,$lgc,80,35,"Vendredi", "libellebas");
        zonetexte($data,"horSam","horSamedi","champtexte",false,$lgc,80,35,"Samedi", "libellebas");
        echo '<div class="libellebas">Cadre : Stage TS</div><div class="champtexte">'.$data["annee"].'</div>';
        echo '</td></tr></table>';
        
if (!(isset($_GET["mode"]))) { 
?>
<div class="centrer"><span class="oblig">*</span> champ obligatoire<input type="submit" name="enregistrer" value="<?php if (isset($data["stage"])) echo("Mettre à jour"); else echo("Créer la fiche"); ?>"/></div>
<?php } ?>

</form>
</div>
  