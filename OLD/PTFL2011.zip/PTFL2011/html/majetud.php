<?php
$cnx=mysqli_connect("localhost","root","mpmsql","portfolio");
$res=mysqli_query($cnx,"select * from port_etudiant");

while($letud=mysqli_fetch_array($res)) {echo $letud["nom"]."<br/>";
$reqProfil="select * from profil where pro_nom='".$letud["nom"]."'";
$resProfil=mysqli_query($cnx,$reqProfil);
$cursProfil=mysqli_fetch_array($resProfil);
if ($cursProfil!=NULL) {

$req="update port_posseder set  idEtud=".$letud["num"]." where idEtud=".$cursProfil["PRO_CODE"];
echo $req."<br/>";
mysqli_query($cnx,$req);
}
}





?>