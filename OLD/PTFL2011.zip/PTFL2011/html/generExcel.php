<?php

  function renseigneActivite($pConnexion, $pRequete,$pLigne, $pTableur, $pPrefixe) {
    $nbLignes=0; //nombre de lignes traitées
    $cursSit=mysqli_query($pConnexion,$pRequete);
    while ($uneSit=mysqli_fetch_assoc($cursSit)) {
        //renseigne l'intitulé dans la première colonne et la date de réalisation (date fin) en colonne F
        $pTableur->setActiveSheetIndex(0)
                ->setCellValue("A".$pLigne, $uneSit["libcourt"]);
        $pTableur->setActiveSheetIndex(0)
                ->setCellValue("F".$pLigne, $uneSit["datefin"]);
        //renseigne les activités obligatoires, indique le niveau sélectionné (observé-1 à expert-5)
        $reqOblig="Select codeTypologie from ".$pPrefixe."esttypo where refSituation=".$uneSit["ref"];
        $cursOblig=mysqli_query($pConnexion,$reqOblig) or die("typo");
        while ($uneTypo=mysqli_fetch_assoc($cursOblig))  {
        $pTableur->setActiveSheetIndex(0)
                ->setCellValueByColumnAndRow($uneTypo["codeTypologie"],$pLigne,$uneSit["codeType"]);            
        }
        //renseigne les activités citées (on démarre avec un décalage de 6 colonnes)
        $reqAcCitee="Select idActivite from ".$pPrefixe."activitecitee where refSituation=".$uneSit["ref"];
        $cursAcCitee=mysqli_query($pConnexion,$reqAcCitee) or die("activite");
        while ($uneActivite=mysqli_fetch_assoc($cursAcCitee)) { 
        $pTableur->setActiveSheetIndex(0)
                ->setCellValueByColumnAndRow($uneActivite["idActivite"]+5,$pLigne,$uneSit["codeType"]);            
        };
        $pLigne++; //pour passer à la liogne suivante
        $nbLignes++; //pour compter le nombre de lignes        
    }
    return $nbLignes;
}


//création de l'objet PhpExcel et ouverture du fichier de base 
require_once './vue/PHPExcel.php';
$pointeurExcel =  PHPExcel_IOFactory::createReader('Excel2007');
$excel = $pointeurExcel->load('./dirrw/param/modelePortefeuille19.xlsx');
$excel->setActiveSheetIndex(0);
//annule la mise en cache des calculs
PHPExcel_Calculation::getInstance()->disableCalculationCache();

//connexion à la base
$cnx=mysqli_connect("localhost","ptfl","admptfl","portfolio");
$prefixeTables="port_";
//rÈcup des donnÈes de formulaire
$idEtud=$_GET["id"]; 

//informations sur l'étudiant en cours et sur son option
$req="select pe.*, pg.idParcours
			from ".$prefixeTables."etudiant as pe, ".$prefixeTables."groupe as pg 
			where pe.numGroupe=pg.num and pe.num='".$idEtud."'";
$curs=mysqli_query($cnx,$req);
$lEtud=mysqli_fetch_assoc($curs);

//inscription des entêtes (nom/prénom, numéro d'étudiant et parcours
$excel->setActiveSheetIndex(0)
            ->setCellValue("D2",$lEtud["nom"]." ".$lEtud["prenom"]);
$excel->setActiveSheetIndex(0)
            ->setCellValue("AX2", $lEtud["numexam"]);
if ($lEtud["idParcours"]==1)  
	$parcours="SISR"; 
else 
	$parcours="SLAM";
$excel->setActiveSheetIndex(0)
            ->setCellValue("AG2", $parcours);
//situations de l'étudiant
//positionnement des lignes dans le tableur
$debScol=6; //situations scolaires
$debST1=60; //stage 1
$debST2=91; //stage2
$finST2=115; //dernière ligne des situations
$nbScol=0; // nombre de situations scolaires
$nbST1=0; //nombre situtations stage1
$nbST2=0 ; //nombre situations stage2
//gestion du placement par type de contenu (scolaire à partir de la ligne 6, stage1 ligne 30, stage2 ligne 47)
$reqSituationsScol="select * from ".$prefixeTables."situation where codeSource>2 and numEtudiant='".$idEtud."' order by datefin asc";  //scolaire
$nbScol=renseigneActivite($cnx, $reqSituationsScol,$debScol, $excel, $prefixeTables);
$reqSituationsSt1="select * from ".$prefixeTables."situation where codeSource=1 and numEtudiant='".$idEtud."' order by datefin asc";  //stage 1
$nbST1=renseigneActivite($cnx, $reqSituationsSt1,$debST1, $excel, $prefixeTables);
$reqSituationsSt2="select * from ".$prefixeTables."situation where codeSource=2 and numEtudiant='".$idEtud."' order by datefin asc";  //stage 2
$nbST2=renseigneActivite($cnx, $reqSituationsSt2,$debST2, $excel, $prefixeTables);

//mise à la bonne largeur des colonnes
$excel->setActiveSheetIndex(0)->getColumnDimension("A")->setWidth(80);
$excel->setActiveSheetIndex(0)->getColumnDimension("F")->setWidth(12);

//Réapplication des styles suite au remplissage
	$styleG4=$excel->setActiveSheetIndex(0)->getStyle('G4'); //entête
	$excel->setActiveSheetIndex(0)->duplicateStyle($styleG4,'G4:BB4');
	$styleG6=$excel->setActiveSheetIndex(0)->getStyle('G6'); //cellule 
	$excel->setActiveSheetIndex(0)->duplicateStyle($styleG6,"G6:BB".$finST2);

               
//suppressions des colonnes inutiles selon le parcours SLAM/SISR et réapplication des styles
if ($parcours=="SLAM") {
	//enlève les activités A3 du profil SISR en commençant par la fin
	$excel->setActiveSheetIndex(0)->removeColumn("AH",6);
	$excel->setActiveSheetIndex(0)->removeColumn("AC",3);
}
else {//parcours SISR enlève les activités SLAM
	$excel->setActiveSheetIndex(0)->removeColumn("AW",4);
	$excel->setActiveSheetIndex(0)->removeColumn("AQ",3);
	$excel->setActiveSheetIndex(0)->removeColumn("AN",1);

}


//suppressions des lignes blanches
$excel->setActiveSheetIndex(0)->removeRow($debST2+$nbST2+2,($finST2-$debST2-$nbST2)); //stage2
$excel->setActiveSheetIndex(0)->removeRow($debST1+$nbST1+2,($debST2-3-$debST1-$nbST1)); //stage1
$excel->setActiveSheetIndex(0)->removeRow($debScol+$nbScol+2,($debST1-3-$debScol-$nbScol)); //scolaire
$finScol=$debScol+$nbScol+1;
$debST1=$finScol+2;
$finST1=$debST1+$nbST1+1;
$debST2=$finST1+2;
$finST2=$debST2+$nbST2+1;
$totObs=$finST2+1;


//écriture du fichier, qui écrase les anciennes versions. Il n'y a pas d'historique
$objWriter = PHPExcel_IOFactory::createWriter($excel, "Excel2007");
$objWriter->save("./dirrw/exportExcel/tableauSynthese".$idEtud.".xlsx");
echo 'Vous pouvez r&eacute;cup&eacute;rer le tableur <a href="./dirrw/exportExcel/tableauSynthese'.$idEtud.'.xlsx">ici</a>';
echo '<br>Ce tableau est généré à chaque demande, il n\'est pas conservé';
echo '<br>Vous pouvez ensuite fermer la fen&ecirc;tre';

?>