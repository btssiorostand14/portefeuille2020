1#
Promotion#
<p>Ce menu permet de s&eacute;lectionner une promotion parmi celles que vous g&eacute;rez.
 Si l'une d'elle n'apparait pas dans la liste, ou si celle-ci est vide,
 il appartient &agrave; l'administrateur de r&eacute;aliser le lien enseignant - promotion</p>

