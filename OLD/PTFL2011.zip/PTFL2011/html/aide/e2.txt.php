2# Synth&egrave;se#
<p>Ce menu permet de connaitre quelles sont les activit&eacute;es cit&eacute;es
  parmi celles pr&eacute;vues au r&eacute;f&eacute;rentiel ; idem pour les comp&eacute;tences.</p>
<p>Vous pouvez visualiser votre tableau de synth&egrave;se au format PDF.</p>
<p>Toutes les informations saisies ne figurent pas sur ce document.</p>
<p>&nbsp;</p>
