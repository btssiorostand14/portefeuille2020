3#
Donn&eacute;es#

<h4>Synth&egrave;se</h4>
<p>Vous pouvez consulter le tableau de synth&egrave;se ou le tableau bilan d'un &eacute;tudiant que
  vous s&eacute;lectionnez dans la liste des &eacute;tudiants de votre promotion.</p>
