3# Divers#
<p>Ce menu permet de r&eacute;aliser une sauvegarde de vos donn&eacute;es personnelles
  ou de modifier vos param&egrave;tres.</p>
<h4>Sauvegarde</h4>
<p>Cet item r&eacute;alise une sauvegarde de vos donn&eacute;es personnelles au
  format XML. Vous devrez enregistrer sur votre cl&eacute; USB ou tout autre
  support le fichier qui vous sera propos&eacute;. Dans la fen&ecirc;tre du navigateur
  qui s'ouvre vous observez le contenu du fichier xml ; vous utilisez la commande
  &quot;Fichier/Enregistrer sous&quot; de votre navigateur pour r&eacute;aliser
  l'enregistrement sur votre cl&eacute; USB ou votre disque. </p>
<h4>Param&egrave;tres</h4>
<p>Cet item vous permet de rectifier ou modifier vos donn&eacute;es personnelles (nom, pr&eacute;nom,
 adresse m&eacute;l) ; le changement de mot de passe n'est effectif qu'en cochant la case correspondante.</p>

