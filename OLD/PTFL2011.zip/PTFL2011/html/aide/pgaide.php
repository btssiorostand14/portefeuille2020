
<?php

include 'aide.class.php';

echo new Aide($_GET["qui"]);

?>
