4#
Divers#
<p>Ce menu permet de restaurer les donn&eacute;es d'un &eacute;tudiant et de modifier
  vos propres param&egrave;tres.</p>
<h4>Restauration</h4>
<p>Cet item ne sera actif que quand la structure des donn&eacute;es sera valid&eacute;e.</p>
<p>Cet item permet de restaurer les donn&eacute;es d'un &eacute;tudiant. Ce dernier
  doit disposer d'une sauvegarde qu'il a enregistr&eacute;e sur sa cl&eacute;
  USB par exemple. La restauration de ses donn&eacute;es personnelles sera celel
  existant lors de la sauvegarde propos&eacute;e.</p>
<p>Typiquement il s'agit ici de revenir &agrave; un &eacute;tat ant&eacute;rieur
  apr&egrave;s une mauvaise manipulation ou un effacement accidentel.</p>
<h4>Param&egrave;tres</h4>
<p>Cet item vous permet de modifier vos donn&eacute;es personnelles (nom, pr&eacute;nom,
  m&eacute;l, mot de passe). Les modifications prendront effet d&egrave;s la prochaine
  connexion. </p>
