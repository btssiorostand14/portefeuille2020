2#
Suivi# 
<p>Ce menu permet de g&eacute;rer les donn&eacute;es des &eacute;tudiants appartenant 
  au groupe dont vous avez saisi l'identifiant lors de votre connexion.</p>
<p>Diff&eacute;rents onglets permettent de r&eacute;aliser des filtres afin de 
  ne voir dans la liste que les situarions qui doivent &ecirc;tre vues.</p>
 <h4>Derni&egrave;res non comment&eacute;es</h4>
 <p>Il s'agit des situations saisies ou modifi&eacute;es &agrave; une date ult&eacute;rieure &agrave; votre dernier
 commentaire et qui n'ont &eacute;t&eacute; comment&eacute;es par aucun professeur</p>
<h4>Derni&egrave;res</h4>
<p>Il s'agit des situations saisies ou modifi&eacute;es &agrave; une date ult&eacute;rieure &agrave; votre dernier
 commentaire</p>
<h4>Non comment&eacute;es</h4>
<p>Situations n'ayant fait l'objet d'aucun commentaire par un professeur</p>
