3#
Restauration#
&lt;p&gt;Cette fonctionnalit&eacute; n'est pas encore activ&eacute;e, dans l'attente d'une stabilisation de la structure de la base<p>
<p>Ce menu permet de restaurer les donn&eacute;es pr&eacute;alablement sauvegard&eacute;es
  par un &eacute;tudiant sur sa cl&eacute; USB ou tout autre support.</p>
<p>La sauvegarde r&eacute;guli&egrave;re des donn&eacute;es est de la responsabilit&eacute;
  de l'&eacute;tudiant. En fournissant &agrave; l'administrateur une sauvegarde
  &agrave; jour sur sa cl&eacute; USB, l'ensemble de ses donn&eacute;es (situations,
  comp&eacute;tences, commentaires, validations) seront restaur&eacute;es.</p>
<p>Dans le cas d'un &eacute;tudiant provenant de l'ext&eacute;rieur (changement
  d'&eacute;tablissement par exemple), &agrave; condition qu'il ait r&eacute;alis&eacute;
  une sauvegarde sur une application identique ou qu'il dispose d'un document
  XML conforme &agrave; la DTD disponible, l'administrateur travaille en deux
  phases :</p>
<p>- d'abord cr&eacute;ation d'un compte &eacute;tudiant avec une adresse m&eacute;l
  strictement identique &agrave; celle indiqu&eacute;e dans la sauvegarde ;</p>
<p>- ensuite restauration des donn&eacute;es.</p>
<p>&nbsp;</p>
