2#
Codes d'acc&egrave;s#

<p>Ce menu permet de communiquer les mots de passe aux utilisateurs.</p>
<p>Cette fonctionnalit&eacute; n'existe que si les mots de passe ne sont pas crypt&eacute;s
(confer param&egrave;tres d'installation). Si l'application dispose d'un serveur SMTP, les
mots de passe ont &eacute;t&eacute; envoy&eacute;s par m&eacute;l aux utilisateurs. S'il n'y a pas de serveur SMTP et que les mots
 de passe doivent &ecirc;tre crypt&eacute;s, l'application affecte &agrave; tout nouvel utilisateur le
 mot de passe &quot;ABCD&quot; qui doit &ecirc;tre ensuite modifi&eacute; par son propri&eacute;taire</p>
<p>Apr&egrave;s avoir cr&eacute;&eacute; les promotions puis les comptes des professeurs
  et des &eacute;tudiants, un mot de passe initial a &eacute;t&eacute; g&eacute;n&eacute;r&eacute;
  par l'application pour chaque utilisateur. Il faut donc en informer les titulaires
  du compte.</p>
<h4>Export mots de passe</h4>
<p>&Agrave; partir de la s&eacute;lection d'une promotion, vous obtenez un fichier
  csv comportant les &eacute;l&egrave;ves qui en sont membres. Vous pouvez ouvrir
  ce document avec un tableur pour pouvoir communiquer individuellement son mot
  de passe &agrave; chaque &eacute;tudiant.</p>
<h4>&nbsp;</h4>
